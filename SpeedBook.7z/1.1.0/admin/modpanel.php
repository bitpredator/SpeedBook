

<?php

error_reporting(E_ALL);
ini_set('display_errors', 1);
session_start();
if ( $_SESSION['loggedin'] != 1 ) {
  $_SESSION['message'] = "You must log in before viewing your profile page!";
  header("location: ../error.php");
	exit();
}
elseif ( $_SESSION['moderatorlevel'] != "1" ) {
	$_SESSION['errormessage'] = "You are not a moderator!";
	header("location: ../error.php");
	exit();
}
require '../connect.php';
$sql = "SELECT vtcname FROM vtcinformation";
    $stmt = $pdo->prepare($sql);
    $stmt->execute();
    $user = $stmt->fetch(PDO::FETCH_ASSOC);
	$vtcname = $user['vtcname'];
$sql2 = "SELECT anntitle, annmessage FROM announcements";
    $stmt = $pdo->prepare($sql2);
    $stmt->execute();
    $user = $stmt->fetch(PDO::FETCH_ASSOC);
	$anntitle = $user['anntitle'];
	$annmessage = $user['annmessage'];
?>


<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title><?= $vtcname ?> - Mod Dashboard</title>
<?php include 'css/css.html'; ?>
</head>

<body>
	<div class="form">
		<div class="ann">
			<center><font color="white">Welcome back, <?= $_SESSION['username'] ?>!</font></center>
			<?php
			$sql = "SELECT COUNT(id) as id FROM pm WHERE isread='0' and recipient=:me";
			$stmt = $pdo->prepare($sql);
			$stmt->bindValue(':me', $_SESSION['username']);
    		$stmt->execute();
    		$user = $stmt->fetch(PDO::FETCH_ASSOC);
			if($user['id'] > 0){
				echo '<br><center><font color="white"><a href="pm/view-messages.php">You have a new message!</a></font></center>';
			}
				else{
				}
?>
		</div><br>
		<?php
			echo "<div class='ann'><h2>Version Check:</h2><br>";
		?>
		<?php
			$update = file_get_contents('http://www.picmount.ca/current-version.txt');
			$currentversion = file_get_contents('../current-version.txt');
		if ($update > $currentversion){
			echo "<center><font color='red'><b>New Version Avalible! <a href='https://github.com/Kielly32/PicmountVTC/raw/master/$update.rar'>Download Here.</a></b></font></center>";
		}
		else {
			echo "<center><font color='limegreen'><b>No new updates. Running current version $currentversion</b></font></center> ";
		}
			echo "</div>";
		?>
		<div class="form">
			<div class="tab-content"> 
				<div id="signup">
					<div id="quicklinks">
						<center>
						<table>
							<thead>
								<tr>
									<th>Logger</th>
								</tr>
							</thead>
							<tbody>
								<tr>
						<th><a href="log/managejob.php"><button title="Job" target="_self" class="dashlinks dashlinks-block">Manage Jobs</button></a>
						<a href="log/manageincident.php"><button title="Incident" target="_self" class="dashlinks dashlinks-block">Manage Incidents</button></a>
						<a href="log/managemaintenance.php"><button title="Maintenance" target="_self" class="dashlinks dashlinks-block">Manage Maintenance</button></a></th>
								</tr>
							</tbody>
						</table>
						<table><br>
						<table>
							<thead>
								<tr>
									<th>Users</th>
								</tr>
							</thead>
							<tbody>
								<tr>
									<th><a href="users/list.php"><button title="List Users" target="_self" class="dashlinks dashlinks-block">List Users</button></a>
									<a href="#"><button title="Ban" target="_self" class="dashlinkscs dashlinks-block">Ban Users (Use List Users)</button></a></th>
								</tr>
							</tbody>
							</table><br>
						<table>
							<thead>
								<tr>
									<th>Reports</th>
								</tr>
							</thead>
							<tbody>
								<tr>
						<th><a href="reports/unresolved.php"><button title="Unresolved" target="_self" class="dashlinks dashlinks-block">Unresolved</button></a>
						<a href="reports/resolved.php"><button title="Settings" target="_self" class="dashlinks dashlinks-block">Resolved/Archive</button></a></th>
								</tr>
							</tbody>
						</table>	
						<br><a href="livenotes.php"><button title="Unresolved" target="_self" class="dashlinks dashlinks-block">Project Developer Live Notes</button></a>
						</center>
					</div><!-- end quick links-->
				</div><!-- end maintab-->
				<div id="login">
					<div id="quicklinks">
						<center>
						</center>
					</div><!-- end quick links-->
				</div><!-- end logtab-->

			</div><!-- end tab-content-->
	</div>
		<a href="../dashboard.php"><button class="button button-block" name="logout"/>Back</button></a><br>
		<?php
		if ( $_SESSION['adminlevel'] == 1 ) {
  		echo '<a href="adminpanel.php"><button class="button button-block" name="logout"/>Admin Panel</button></a><br>';
		exit();
		}
		?>
		
	</div><!-- end form2-->
<script src='http://cdnjs.cloudflare.com/ajax/libs/jquery/2.1.3/jquery.min.js'></script>
<script src="js/index.js"></script>
</body>
</html>