<?php
session_start();
$jobid=$_REQUEST['id'];
require '../../connect.php';
if ( $_SESSION['loggedin'] != 1 ) {
  $_SESSION['message'] = "You must log in before viewing your profile page!";
  header("location: ../../error.php");
	exit();
}
elseif ( $_SESSION['moderatorlevel'] != "1" ) {
	$_SESSION['errormessage'] = "You are not a moderator!";
	header("location: ../../error.php");
	exit();
}
?>
<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>View Job</title>
<script src="http://ajax.googleapis.com/ajax/libs/jquery/1.11.1/jquery.min.js">        </script>
<script src="js/typeahead.min.js"></script>
<?php include 'css/css.html'; ?>
</head>

<body>
	<div class="form">
		<ul class="tab-group">
			<div class="form">  
				<div class="tab-content"> 
					<h1>Job ID:<?= $jobid ?></h1><br>
					
					<?php
					$sql = "SELECT * FROM jobslog WHERE id=$jobid ORDER BY id desc";
					$stmt = $pdo->prepare($sql);
					$stmt->execute();
					$user = $stmt->fetch(PDO::FETCH_ASSOC);
						$depcity = $user['depcity'];
						$arrcity = $user['arrcity'];
						$cargo = $user['cargo'];
						$fuelcon = $user['fuelcon'];
						$weight = $user['weight'];
						$profits = $user['profits'];
						$toll = $user['toll'];
						$comment = $user['comment'];
						$emp = $user['emp'];
						$pay = $user['pay'];
						$date = $user['date'];
						$distance = $user['distance'];
					?>
					
					
					<font color="#1ab188">Departure City: </font><font color="white"><?= $depcity ?></font><br>
					<font color="#1ab188">Arriving City: </font><font color="white"><?= $arrcity ?></font><br>
					<font color="#1ab188">Cargo: </font><font color="white"><?= $cargo ?></font><br>
					<font color="#1ab188">Fuel Used: </font><font color="white"><?= $fuelcon ?>L</font><br>
					<font color="#1ab188">Weight: </font><font color="white"><?= $weight ?>Tons</font><br>
					<font color="#1ab188">Profits: </font><font color="white">$<?= $profits ?></font><br>
					<font color="#1ab188">Employee's Pay (35%): </font><font color="white">$<?= $pay ?></font><br>
					<font color="#1ab188">Toll Cost: </font><font color="white">$<?= $toll ?></font><br>
					<font color="#1ab188">Employee: </font><font color="white"><?= $emp ?></font><br>
					<font color="#1ab188">Distance: </font><font color="white"><?= $distance ?>Km</font><br>
					<font color="#1ab188">Date: </font><font color="white"><?= $date ?></font><br>
					<font color="#1ab188">Comment: </font><font color="white"><?= $comment ?></font><br>
					<br><br>
					<a href="deletejob.php?id=<?= $jobid ?>">Delete Job</a>
				</div><!-- end tab-content-->		
			</div><!-- end form-->	
				<a href="../modpanel.php"><button class="button button-block" name="logout"/>Mod Panel</button></a>
		</ul>	
	</div>
<script src='http://cdnjs.cloudflare.com/ajax/libs/jquery/2.1.3/jquery.min.js'></script>
<script src="js/index.js"></script>
	<script>
    $(document).ready(function(){
    $('input.typeahead').typeahead({
        name: 'typeahead',
        remote:'search.php?key=%QUERY',
        limit : 10
    });
});
    </script>
</body>
</html>