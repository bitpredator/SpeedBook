<?php
session_start();
$jobid=$_REQUEST['id'];
require '../../connect.php';
if ( $_SESSION['loggedin'] != 1 ) {
  $_SESSION['message'] = "You must log in before viewing your profile page!";
  header("location: ../../error.php");
	exit();
}
elseif ( $_SESSION['moderatorlevel'] != "1" ) {
	$_SESSION['errormessage'] = "You are not a moderator!";
	header("location: ../../error.php");
	exit();
}
?>
<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>View Job</title>
<script src="http://ajax.googleapis.com/ajax/libs/jquery/1.11.1/jquery.min.js">        </script>
<script src="js/typeahead.min.js"></script>
<?php include 'css/css.html'; ?>
</head>

<body>
	<div class="form">
		<ul class="tab-group">
			<div class="form">  
				<div class="tab-content"> 
					<h1>Job ID:<?= $jobid ?></h1><br>
					
					<?php
					$sql = "SELECT * FROM incidents WHERE id=$jobid ORDER BY id desc";
					$stmt = $pdo->prepare($sql);
					$stmt->execute();
					$user = $stmt->fetch(PDO::FETCH_ASSOC);
						$offence = $user['offence'];
						$damage = $user['damage'];
						$costs = $user['costs'];
						$emp = $user['emp'];
						$comment = $user['comment'];
						$date = $user['date'];
					?>
					
					
					<font color="#1ab188">Offence: </font><font color="white"><?= $offence ?></font><br>
					<font color="#1ab188">Trailer Damage: </font><font color="white"><?= $damage ?>%</font><br>
					<font color="#1ab188">Costs: </font><font color="white">$<?= $costs ?></font><br>
					<font color="#1ab188">Employee: </font><font color="white"><?= $emp ?></font><br>
					<font color="#1ab188">Comment: </font><font color="white"><?= $comment ?></font><br>
					<font color="#1ab188">Date: </font><font color="white"><?= $date ?></font><br>
					<br><br>
					<a href="deleteincident.php?id=<?= $jobid ?>">Delete Job</a>
				</div><!-- end tab-content-->		
			</div><!-- end form-->	
				<a href="../modpanel.php"><button class="button button-block" name="logout"/>Mod Panel</button></a>
		</ul>	
	</div>
<script src='http://cdnjs.cloudflare.com/ajax/libs/jquery/2.1.3/jquery.min.js'></script>
<script src="js/index.js"></script>
	<script>
    $(document).ready(function(){
    $('input.typeahead').typeahead({
        name: 'typeahead',
        remote:'search.php?key=%QUERY',
        limit : 10
    });
});
    </script>
</body>
</html>