<?php
session_start();
$jobid=$_REQUEST['id'];
require '../../connect.php';
if ( $_SESSION['loggedin'] != 1 ) {
  $_SESSION['message'] = "You must log in before viewing your profile page!";
  header("location: ../../error.php");
	exit();
}
elseif ( $_SESSION['adminlevel'] != "1" ) {
	$_SESSION['errormessage'] = "You are not an Admin!";
	header("location: ../../error.php");
	exit();
}
?>

<?php
if(isset($_POST['submit'])){
	$body = !empty($_POST['body']) ? trim($_POST['body']) : null;
	$title = !empty($_POST['title']) ? trim($_POST['title']) : null;
	$sql = "INSERT INTO news (title, body, submittedby, date) VALUES (:title, :body, :submittedby, :date)";
    $stmt = $pdo->prepare($sql);
	
	$stmt->bindValue(':title', $title);
	$stmt->bindValue(':body', $body);
	$stmt->bindValue(':submittedby', $_SESSION['username']);
	$stmt->bindValue(':date', date("Y-m-d h:i:s"));
	
	$result = $stmt->execute();
    
    if($result){
		$message = 'News Successfully Added!';

    echo "<SCRIPT type='text/javascript'> //not showing me this
        alert('$message');
        window.location.replace(\"../adminpanel.php\");
    </SCRIPT>";
    }
	else {
		$_SESSION['errormessage'] = 'Failed to update reports.';
		header("location: ../../error.php");
		exit();
	}
}
?>
<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>Create News</title>
<script src="http://ajax.googleapis.com/ajax/libs/jquery/1.11.1/jquery.min.js">        </script>
<script src="js/typeahead.min.js"></script>
<?php include 'css/css.html'; ?>
</head>

<body>
	<div class="form">
		<ul class="tab-group">
			<div class="form">  
				<div class="tab-content"> 
					<h1>New News Article:</h1><br>
					<form action="cnews.php" method="post">
						<div class="field-wrap">
            				<font color="white">Title</font>
            				<input type="text" id="title" name="title">
						 </div>
						<div class="field-wrap">
							<br><font color="white">Body</font>
            				<textarea id="body" name="body" maxlength="200" cols="25" rows="7" class="messagebox"></textarea>
						 </div>
						<input type="submit" name="submit" value="Add Article" class="button button button-block">
					</form>
				</div><!-- end tab-content-->		
			</div><!-- end form-->	
				<a href="../adminpanel.php"><button class="button button-block" name="logout"/>Back</button></a>
		</ul>	
	</div>
<script src='http://cdnjs.cloudflare.com/ajax/libs/jquery/2.1.3/jquery.min.js'></script>
<script src="js/index.js"></script>
	<script>
    $(document).ready(function(){
    $('input.typeahead').typeahead({
        name: 'typeahead',
        remote:'search.php?key=%QUERY',
        limit : 10
    });
});
    </script>
</body>
</html>