<?php
session_start();
require '../../connect.php';
if ( $_SESSION['loggedin'] != 1 ) {
  $_SESSION['message'] = "You must log in before viewing your profile page!";
  header("location: ../../error.php");
	exit();
}
elseif ( $_SESSION['moderatorlevel'] != "1" ) {
	$_SESSION['errormessage'] = "You are not a moderator!";
	header("location: ../../error.php");
	exit();
}
?>

<?php
if(isset($_POST['register'])){
	$userid = $_POST['username'];
	header("location: viewusers?id=$userid");
	exit();
}
?>
<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>Ban User</title>
<script src="http://ajax.googleapis.com/ajax/libs/jquery/1.11.1/jquery.min.js">        </script>
<script src="js/typeahead.min.js"></script>
<?php include 'css/css.html'; ?>
</head>

<body>
	<div class="form">
		<ul class="tab-group">
			<div class="form">  
				<div class="tab-content"> 
					<center></center><br><form action="ban.php" method="post">
					<h1>Enter Username Below</h1><br><br>
						<br /><div class="field-wrap">
            				<label for="username">Username</label>
            				<input type="text" id="username" name="username" maxlength="45" required autocomplete="new-password"><br>
						</div>
			
            <input type="submit" name="register" value="Search" class="button button button-block"></button>
					</form>
				</div><!-- end tab-content-->		
			</div><!-- end form-->	
				<a href="../modpanel.php"><button class="button button-block" name="logout"/>Mod Panel</button></a>
		</ul>	
	</div>
<script src='http://cdnjs.cloudflare.com/ajax/libs/jquery/2.1.3/jquery.min.js'></script>
<script src="js/index.js"></script>
	<script>
    $(document).ready(function(){
    $('input.typeahead').typeahead({
        name: 'typeahead',
        remote:'search.php?key=%QUERY',
        limit : 10
    });
});
    </script>
</body>
</html>