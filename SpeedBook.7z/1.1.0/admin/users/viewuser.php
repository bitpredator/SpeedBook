<?php
session_start();
$jobid=$_REQUEST['id'];
require '../../connect.php';
if ( $_SESSION['loggedin'] != 1 ) {
  $_SESSION['message'] = "You must log in before viewing your profile page!";
  header("location: ../../error.php");
	exit();
}
elseif ( $_SESSION['moderatorlevel'] != "1" ) {
	$_SESSION['errormessage'] = "You are not a moderator!";
	header("location: ../../error.php");
	exit();
}
?>
<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>View User</title>
<script src="http://ajax.googleapis.com/ajax/libs/jquery/1.11.1/jquery.min.js">        </script>
<script src="js/typeahead.min.js"></script>
<?php include 'css/css.html'; ?>
</head>

<body>
	<div class="form">
		<ul class="tab-group">
			<div class="form">  
				<div class="tab-content"> 
					<h1>User <?= $user['username'] ?></h1><br>
					
					<?php
					$sql = "SELECT * FROM users WHERE id=$jobid ORDER BY id desc";
					$stmt = $pdo->prepare($sql);
					$stmt->execute();
					$user = $stmt->fetch(PDO::FETCH_ASSOC);
						$firstname = $user['firstname'];
						$lastname = $user['lastname'];
						$email = $user['email'];
						$truckersmpurl = $user['truckersmpurl'];
						$steam64id = $user['steam64id'];
						$steamurl = $user['steamurl'];
						$bank = $user['bank'];
						$totaldeliveries = $user['totaldeliveries'];
						$totalkms = $user['totalkms'];
						$totaloffences = $user['totaloffences'];
						$userlevel = $user['userlevel'];
						$moto = $user['moto'];
						$regdate = $user['regdate'];
						$banned = $user['banned'];
					?>
					
					
					<font color="#1ab188">First Name: </font><font color="white"><?= $firstname ?></font><br>
					<font color="#1ab188">Last Name: </font><font color="white"><?= $lastname ?></font><br>
					<font color="#1ab188">Email: </font><font color="white"><?= $email ?></font><br>
					<font color="#1ab188">TruckersMP Profile: </font><font color="white"><?= $truckersmpurl ?></font><br>
					<font color="#1ab188">Steam64id: </font><font color="white"><?= $steam64id ?></font><br>
					<font color="#1ab188">Steam Profile: </font><font color="white"><?= $steamurl ?></font><br>
					<font color="#1ab188">Bank: </font><font color="white"><?= $bank ?></font><br>
					<font color="#1ab188">Total Deliveries: </font><font color="white"><?= $totaldeliveries ?></font><br>
					<font color="#1ab188">Total Kms: </font><font color="white"><?= $totalkms ?></font><br>
					<font color="#1ab188">Total Offences: </font><font color="white"><?= $totaloffences ?></font><br>
					<font color="#1ab188">User Level: </font><font color="white"><?= $userlevel ?></font><br>
					<font color="#1ab188">Motto: </font><font color="white"><?= $moto ?></font><br>
					<font color="#1ab188">Registration Date: </font><font color="white"><?= $regdate ?></font><br>
					<font color="#1ab188">Banned? </font><font color="white"><?= $banned ?> (0 = No | 1 = Yes)</font><br>
					<br><br>
					<a href="banuser.php?id=<?= $jobid ?>">Ban User</a><br>
					<a href="unbanuser.php?id=<?= $jobid ?>">Unban User</a>
				</div><!-- end tab-content-->		
			</div><!-- end form-->	
				<a href="../modpanel.php"><button class="button button-block" name="logout"/>Mod Panel</button></a>
		</ul>	
	</div>
<script src='http://cdnjs.cloudflare.com/ajax/libs/jquery/2.1.3/jquery.min.js'></script>
<script src="js/index.js"></script>
	<script>
    $(document).ready(function(){
    $('input.typeahead').typeahead({
        name: 'typeahead',
        remote:'search.php?key=%QUERY',
        limit : 10
    });
});
    </script>
</body>
</html>