<?php
session_start();
$jobid=$_REQUEST['id'];
require '../../connect.php';
if ( $_SESSION['loggedin'] != 1 ) {
  $_SESSION['message'] = "You must log in before viewing your profile page!";
  header("location: ../../error.php");
	exit();
}
elseif ( $_SESSION['moderatorlevel'] != "1" ) {
	$_SESSION['errormessage'] = "You are not a moderator!";
	header("location: ../../error.php");
	exit();
}
?>

<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>Report Archive</title>
<script src="http://ajax.googleapis.com/ajax/libs/jquery/1.11.1/jquery.min.js">        </script>
<script src="js/typeahead.min.js"></script>
<?php include 'css/css.html'; ?>
</head>

<body>
	<div class="form">
		<ul class="tab-group">
			<div class="form">  
				<div class="tab-content"> 
					<h1>Report ID(<?= $jobid ?>)</h1><br>
					<?php
					$sql = "SELECT * FROM reports WHERE id=$jobid ORDER BY id desc";
					$stmt = $pdo->prepare($sql);
					$stmt->execute();
					$user = $stmt->fetch(PDO::FETCH_ASSOC);
						$username = $user['username'];
						$modname = $user['modname'];
						$reporttype = $user['reporttype'];
						$comment = $user['comment'];
						$resolution = $user['resolution'];	
						$date = $user['date'];
					?>
					<font color="#1ab188">Username: </font><font color="white"><?= $username ?></font><br>
					<font color="#1ab188">Report Type: </font><font color="white"><?= $reporttype ?></font><br>
					<font color="#1ab188">Date: </font><font color="white"><?= $date ?></font><br>
					<font color="#1ab188">Comment: </font><font color="white"><?= $comment ?></font><br>
					<font color="#1ab188">Resolution: </font><font color="white"><?= $resolution ?></font><br>
					<font color="#1ab188">Mod Name: </font><font color="white"><?= $modname ?></font><br>
				</div><!-- end tab-content-->		
			</div><!-- end form-->	
				<a href="resolved.php"><button class="button button-block" name="logout"/>Back</button></a>
		</ul>	
	</div>
<script src='http://cdnjs.cloudflare.com/ajax/libs/jquery/2.1.3/jquery.min.js'></script>
<script src="js/index.js"></script>
	<script>
    $(document).ready(function(){
    $('input.typeahead').typeahead({
        name: 'typeahead',
        remote:'search.php?key=%QUERY',
        limit : 10
    });
});
    </script>
</body>
</html>