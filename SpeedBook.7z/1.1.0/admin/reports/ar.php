<?php
session_start();
$jobid=$_REQUEST['id'];
require '../../connect.php';
if ( $_SESSION['loggedin'] != 1 ) {
  $_SESSION['message'] = "You must log in before viewing your profile page!";
  header("location: ../../error.php");
	exit();
}
elseif ( $_SESSION['moderatorlevel'] != "1" ) {
	$_SESSION['errormessage'] = "You are not a moderator!";
	header("location: ../../error.php");
	exit();
}
?>

<?php
if(isset($_POST['submit'])){
	$resolution = !empty($_POST['resolution']) ? trim($_POST['resolution']) : null;
	$sql = "UPDATE reports SET resolution = :resolution, isresolved = :isresolved, modname = :modname WHERE id=$jobid";
    $stmt = $pdo->prepare($sql);
	
	$stmt->bindValue(':resolution', $resolution);
	$stmt->bindValue(':isresolved', '1');
	$stmt->bindValue(':modname', $_SESSION['username']);
	
	$result = $stmt->execute();
    
    if($result){
		$message = 'Report Successfully Updated!';

    echo "<SCRIPT type='text/javascript'> //not showing me this
        alert('$message');
        window.location.replace(\"unresolved.php\");
    </SCRIPT>";
    }
	else {
		$_SESSION['errormessage'] = 'Failed to update reports.';
		header("location: ../../error.php");
		exit();
	}
}
?>
<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>Resolve Reports</title>
<script src="http://ajax.googleapis.com/ajax/libs/jquery/1.11.1/jquery.min.js">        </script>
<script src="js/typeahead.min.js"></script>
<?php include 'css/css.html'; ?>
</head>

<body>
	<div class="form">
		<ul class="tab-group">
			<div class="form">  
				<div class="tab-content"> 
					<h1>Resolve Report</h1><br>
					<?php
					$sql = "SELECT * FROM reports WHERE id=$jobid ORDER BY id desc";
					$stmt = $pdo->prepare($sql);
					$stmt->execute();
					$user = $stmt->fetch(PDO::FETCH_ASSOC);
						$username = $user['username'];
						$modname = $user['modname'];
						$reporttype = $user['reporttype'];
						$comment = $user['comment'];
						$resolution = $user['resolution'];	
						$date = $user['date'];
					?>
					<form action="ar.php?id=<?= $jobid ?>" method="post">
						<div class="field-wrap">
            				<font color="white">Username</font>
            				<input type="text" id="Username" name="Username" readonly value="<?= $username ?>">
						 </div>
						<div class="field-wrap">
            				<font color="white">Report Type</font>
            				<input type="text" id="reporttype" name="reporttype" readonly value="<?= $reporttype ?>">
						 </div>
						<div class="field-wrap">
            				<font color="white">Comment</font>
            				<input type="text" id="Comment" name="Comment" readonly value="<?= $comment ?>">
						 </div>
						<div class="field-wrap">
            				<font color="white">Date Submitted</font>
            				<input type="text" id="date" name="date" readonly value="<?= $date ?>">
						 </div>
						<div class="field-wrap">
							<br><font color="white">Your Response</font>
            				<textarea id="resolution" name="resolution" maxlength="200" cols="25" rows="7" class="messagebox"></textarea>
						 </div>
						<input type="submit" name="submit" value="Finish" class="button button button-block">
					</form>
				</div><!-- end tab-content-->		
			</div><!-- end form-->	
				<a href="unresolved.php"><button class="button button-block" name="logout"/>Back</button></a>
		</ul>	
	</div>
<script src='http://cdnjs.cloudflare.com/ajax/libs/jquery/2.1.3/jquery.min.js'></script>
<script src="js/index.js"></script>
	<script>
    $(document).ready(function(){
    $('input.typeahead').typeahead({
        name: 'typeahead',
        remote:'search.php?key=%QUERY',
        limit : 10
    });
});
    </script>
</body>
</html>