<?php
session_start();
require '../../connect.php';
if ( $_SESSION['loggedin'] != 1 ) {
  $_SESSION['message'] = "You must log in before viewing your profile page!";
  header("location: ../../error.php");
	exit();
}
elseif ( $_SESSION['adminlevel'] != "1" ) {
	$_SESSION['errormessage'] = "You are not an Admin!";
	header("location: ../../error.php");
	exit();
}
?>
<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>Delete Users</title>
<script src="http://ajax.googleapis.com/ajax/libs/jquery/1.11.1/jquery.min.js">        </script>
<script src="js/typeahead.min.js"></script>
<?php include 'css/css.html'; ?>
</head>

<body>
	<div class="form">
		<ul class="tab-group">
			<div class="form">  
				<div class="tab-content"> 
					<h1>Delete Users</h1><br>
					<?php
					$sql = "SELECT * FROM users ORDER BY id desc";
					$stmt = $pdo->prepare($sql);
					$stmt->execute();
					while ($user = $stmt->fetch(PDO::FETCH_ASSOC)) {
						$userid = $user['id'];
						echo '<hr><br><font color="#1ab188">Username: </font><font color="white">';
						echo $user['username'];
						echo '</font><br>';
						
						echo '<font color="#1ab188">Email: </font><font color="white">';
						echo $user['email'];
						echo '</font><br>';
						
						echo '<a href="deleteuser.php?id=';
						echo $user['id'];
						echo '">Delete User</a>';
						echo '<br><br><hr><br>';
					}
					?>
					</table>
				</div><!-- end tab-content-->		
			</div><!-- end form-->	
				<a href="../adminpanel.php"><button class="button button-block" name="logout"/>Admin Panel</button></a>
		</ul>	
	</div>
<script src='http://cdnjs.cloudflare.com/ajax/libs/jquery/2.1.3/jquery.min.js'></script>
<script src="js/index.js"></script>
	<script>
    $(document).ready(function(){
    $('input.typeahead').typeahead({
        name: 'typeahead',
        remote:'search.php?key=%QUERY',
        limit : 10
    });
});
    </script>
</body>
</html>