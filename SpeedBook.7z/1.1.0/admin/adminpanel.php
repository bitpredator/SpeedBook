

<?php
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);
session_start();
if ( $_SESSION['loggedin'] != 1 ) {
  $_SESSION['message'] = "You must log in before viewing your profile page!";
  header("location: ../error.php");
	exit();
}
elseif ( $_SESSION['adminlevel'] != "1" ) {
	$_SESSION['errormessage'] = "You are not an Admin!";
	header("location: ../error.php");
	exit();
}
require '../connect.php';
$sql = "SELECT vtcname FROM vtcinformation";
    $stmt = $pdo->prepare($sql);
    $stmt->execute();
    $user = $stmt->fetch(PDO::FETCH_ASSOC);
	$vtcname = $user['vtcname'];
$sql2 = "SELECT anntitle, annmessage FROM announcements";
    $stmt = $pdo->prepare($sql2);
    $stmt->execute();
    $user = $stmt->fetch(PDO::FETCH_ASSOC);
	$anntitle = $user['anntitle'];
	$annmessage = $user['annmessage'];
?>


<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title><?= $vtcname ?> - Admin Dashboard</title>
<?php include 'css/css.html'; ?>
</head>

<body>
	<div class="form">
		<div class="ann">
			<center><font color="white">Welcome back, <?= $_SESSION['username'] ?>!</font></center>
			<?php
			$sql = "SELECT COUNT(id) as id FROM pm WHERE isread='0' and recipient=:me";
			$stmt = $pdo->prepare($sql);
			$stmt->bindValue(':me', $_SESSION['username']);
    		$stmt->execute();
    		$user = $stmt->fetch(PDO::FETCH_ASSOC);
			if($user['id'] > 0){
				echo '<br><center><font color="white"><a href="pm/view-messages.php">You have a new message!</a></font></center>';
			}
				else{
				}
?>
		</div><br>
		<?php
			echo "<div class='ann'><h2>Version Check:</h2><br>";
		?>
		<?php
			$update = file_get_contents('http://www.picmount.ca/current-version.txt');
			$currentversion = file_get_contents('../current-version.txt');
		if ($update > $currentversion){
			echo "<center><font color='red'><b>New Version Avalible! <a href='https://github.com/Kielly32/PicmountVTC/raw/master/$update.rar'>Download Here.</a><br>Remember to update ASAP!</b></font></center>";
		}
		else {
			echo "<center><font color='limegreen'><b>No new updates. Running current version $currentversion</b></font></center> ";
		}
			echo "</div>";
		?>
		<div class="form">
			<div class="tab-content"> 
				<div id="signup">
					<div id="quicklinks">
						<center>
						<table>
							<thead>
								<tr>
									<th>Posts</th>
								</tr>
							</thead>
							<tbody>
								<tr>
						<th><a href="posts/mnews.php"><button title="Job" target="_self" class="dashlinks dashlinks-block">Manage News</button></a>
						<a href="posts/cnews.php"><button title="Incident" target="_self" class="dashlinks dashlinks-block">Create News</button></a>
						<a href="posts/mann.php"><button title="Maintenance" target="_self" class="dashlinks dashlinks-block">Manage<br>Announcements</button></a>
						<a href="posts/cann.php"><button title="Maintenance" target="_self" class="dashlinks dashlinks-block">Create<br> Announcement</button></a></th>
								</tr>
							</tbody>
						</table><br>
						<table>
							<thead>
								<tr>
									<th>Users</th>
								</tr>
							</thead>
							<tbody>
								<tr>
									<th><a href="ausers/addmod.php"><button title="List Users" target="_self" class="dashlinks dashlinks-block">Add Mod</button></a>
									<a href="ausers/mmod.php"><button title="List Users" target="_self" class="dashlinks dashlinks-block">Manage Mods</button></a>
									<a href="ausers/addadmin.php"><button title="List Users" target="_self" class="dashlinks dashlinks-block">Add Admin</button></a>
									<a href="ausers/madmin.php"><button title="Ban" target="_self" class="dashlinks dashlinks-block">Manage Admins</button></a>
									<a href="ausers/delusers.php"><button title="List Users" target="_self" class="dashlinks dashlinks-block">Delete Users</button></a></th>
								</tr>
							</tbody>
							</table><br>
						<table>
							<thead>
								<tr>
									<th>VTC Info</th>
								</tr>
							</thead>
							<tbody>
								<tr>
						<th><font color="white">Comming Soon.</font></th>
								</tr>
							</tbody>
						</table>	
						</center>
					</div><!-- end quick links-->
				</div><!-- end maintab-->
				<div id="login">
					<div id="quicklinks">
						<center>
						</center>
					</div><!-- end quick links-->
				</div><!-- end logtab-->

			</div><!-- end tab-content-->
	</div>
		<a href="../dashboard.php"><button class="button button-block" name="logout"/>Back</button></a><br>
		
	</div><!-- end form2-->
<script src='http://cdnjs.cloudflare.com/ajax/libs/jquery/2.1.3/jquery.min.js'></script>
<script src="js/index.js"></script>
</body>
</html>