<?php
/* Displays all error messages */
session_start();
?>
<!DOCTYPE html>
<html>
<head>
  <title>Error</title>
  <?php include 'css/css.html'; ?>
</head>
<body>
<div class="form">
    <h1>Error</h1>
    <p>
    <?php 
    echo $_SESSION['errormessage'];
    ?>
    </p>     
    <a href="index.php"><button class="button button-block"/>Home</button></a><br>
	<a href="logout.php"><button class="button button-block"/>Logout</button></a>
</div>
</body>
</html>
