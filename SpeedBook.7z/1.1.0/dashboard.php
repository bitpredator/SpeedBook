

<?php
session_start();
if ( $_SESSION['loggedin'] != 1 ) {
  $_SESSION['message'] = "You must log in before viewing your profile page!";
  header("location: error.php");
	exit();
}
elseif ( $_SESSION['banned'] != "0" ) {
	$_SESSION['errormessage'] = "You are banned.";
	header("location: error.php");
	exit();
}
require 'connect.php';
$sql = "SELECT vtcname FROM vtcinformation";
    $stmt = $pdo->prepare($sql);
    $stmt->execute();
    $user = $stmt->fetch(PDO::FETCH_ASSOC);
	$vtcname = $user['vtcname'];
$sql2 = "SELECT anntitle, annmessage FROM announcements";
    $stmt = $pdo->prepare($sql2);
    $stmt->execute();
    $user = $stmt->fetch(PDO::FETCH_ASSOC);
	$anntitle = $user['anntitle'];
	$annmessage = $user['annmessage'];
?>

<?php
$sql = "SELECT COUNT(id) as id FROM jobslog";
$stmt = $pdo->prepare($sql);
    $stmt->execute();
    $user = $stmt->fetch(PDO::FETCH_ASSOC);
	$jobscompleted = $user['id'];
?>
<?php
$sql = "SELECT SUM(distance) as distance FROM jobslog";
$stmt = $pdo->prepare($sql);
    $stmt->execute();
    $user = $stmt->fetch(PDO::FETCH_ASSOC);
	$distance = $user['distance'];
?>
<?php
$sql = "SELECT SUM(profits) as profits FROM jobslog";
$stmt = $pdo->prepare($sql);
    $stmt->execute();
    $user = $stmt->fetch(PDO::FETCH_ASSOC);
	$profits = $user['profits'];
?>
<?php
$sql = "SELECT COUNT(id) as id FROM incidents";
$stmt = $pdo->prepare($sql);
    $stmt->execute();
    $user = $stmt->fetch(PDO::FETCH_ASSOC);
	$incidents = $user['id'];
?>
<?php
$sql = "SELECT COUNT(id) as id FROM users";
$stmt = $pdo->prepare($sql);
    $stmt->execute();
    $user = $stmt->fetch(PDO::FETCH_ASSOC);
	$users = $user['id'];
?>

<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title><?= $vtcname ?> - Dashboard</title>
<?php include 'css/css.html'; ?>
</head>

<body>
	<div class="form">
		<div class="ann">
			<center><font color="white">Welcome back, <?= $_SESSION['username'] ?>!</font></center>
			<?php
			$sql = "SELECT COUNT(id) as id FROM pm WHERE isread='0' and recipient=:me";
			$stmt = $pdo->prepare($sql);
			$stmt->bindValue(':me', $_SESSION['username']);
    		$stmt->execute();
    		$user = $stmt->fetch(PDO::FETCH_ASSOC);
			if($user['id'] > 0){
				echo '<br><center><font color="white"><a href="pm/view-messages.php">You have a new message!</a></font></center>';
			}
				else{
				}
?>
		</div><br>
		<?php
			echo "<div class='ann'><h2>Announcements:</h2><br>";
		?>
		<?php
		$sql = "SELECT * FROM announcements ORDER BY id";
			$stmt = $pdo->prepare($sql);
    		$stmt->execute();
    		while ($user = $stmt->fetch(PDO::FETCH_ASSOC)) {
				if($user['id'] === 0){
					echo "<center><font color='#1ab188'><b>$anntitle - </b></font> ";
					echo "<font color='white'>There are currently no announcements.</font></center><br>";
				}
				else
					echo "<center><font color='#1ab188'><b>$anntitle - </b></font> ";
					echo "<font color='white'>$annmessage</font></center><br>";
		}
			echo "</div>";
		?>
		<div class="form">
			<div class="tab-content"> 
				<div id="signup">
					<div id="quicklinks">
						<center>
						<table>
							<thead>
								<tr>
									<th>Logger</th>
								</tr>
							</thead>
							<tbody>
								<tr>
						<th><a href="log/log.php"><button title="Log Job" target="_self" class="dashlinks dashlinks-block">Log Job</button></a>
						<a href="log/incident.php"><button title="Incident" target="_self" class="dashlinks dashlinks-block">Report Incident</button></a>
						<a href="log/maintenance.php"><button title="Maintenance" target="_self" class="dashlinks dashlinks-block">Report Maintenance</button></a>
						<a href="account/stats.php"><button title="Maintenance" target="_self" class="dashlinks dashlinks-block">View Logs</button></a></th>
								</tr>
							</tbody>
						</table>
						<table><br>
						<table>
							<thead>
								<tr>
									<th>Community</th>
								</tr>
							</thead>
							<tbody>
								<tr>
									<th><a href="#"><button title="Events" target="_self" class="dashlinkscs dashlinks-block">Events (Comming Soon)</button></a>
									<a href="community/news.php"><button title="News" target="_self" class="dashlinks dashlinks-block">News</button></a>
									<a href="community/userlist.php"><button title="Current Users" target="_self" class="dashlinks dashlinks-block">Current Users</button></a>
									<a href="community/report.php"><button title="Report" target="_self" class="dashlinks dashlinks-block">Report</button></a></th>
								</tr>
							</tbody>
							</table><br>
						<table>
							<thead>
								<tr>
									<th>Account</th>
								</tr>
							</thead>
							<tbody>
								<tr>
						<th><a href="account/stats.php"><button title="Stats" target="_self" class="dashlinks dashlinks-block">Your Stats</button></a>
						<a href="#"><button title="Settings" target="_self" class="dashlinkscs dashlinks-block">Settings</button></a>
						<a href="community/user-profile.php?id=<?= $_SESSION['username'] ?>"><button title="Profile" target="_self" class="dashlinks dashlinks-block">Profile</button></a>
						<a href="pm/view-messages.php"><button title="Profile" target="_self" class="dashlinks dashlinks-block">Messages</button></a></th>
								</tr>
							</tbody>
						</table>	
						</center>
					</div><!-- end quick links-->
					<div id="serverinfo">
						<center><table><thead><tr><th>Server Information:</th></tr></thead></table>
						<table class="servertable">
							<thead>
								<tr>
									<th>Jobs Completed</th>
      								<th>KMs Driven</th>
     								<th>Company Value</th>
									<th>Incidents</th>
									<th>Number of Employees</th>
    							</tr>
  							</thead>
							<tbody>
								<?php
									echo "<tr>";
									echo "<td>$jobscompleted</td>";
									echo "<td>$distance Km</td>";
									echo "<td>$$profits</td>";
									echo "<td>$incidents</td>";
									echo "<td>$users</td>";
									echo "</tr>";
								?>
							</tbody>
						</table></center>
					</div><!-- end server info-->
				</div><!-- end maintab-->
				<div id="login">
					<div id="quicklinks">
						<center>
						</center>
					</div><!-- end quick links-->
				</div><!-- end logtab-->

			</div><!-- end tab-content-->
	</div>
		<a href="logout.php"><button class="button button-block" name="logout"/>Log Out</button></a><br>
		<?php
		if ( $_SESSION['adminlevel'] == 1 ) {
  		echo '<a href="admin/adminpanel.php"><button class="button button-block" name="logout"/>Admin Panel</button></a><br>';
		echo '<a href="admin/modpanel.php"><button class="button button-block" name="logout"/>Mod Panel</button></a><br>';
		exit();
		}
		?>
		<?php
		if ( $_SESSION['moderatorlevel'] == 1 ) {
		echo '<a href="admin/modpanel.php"><button class="button button-block" name="logout"/>Mod Panel</button></a><br>';
		exit();
		}
		?>
		
	</div><!-- end form2-->
<script src='http://cdnjs.cloudflare.com/ajax/libs/jquery/2.1.3/jquery.min.js'></script>
<script src="js/index.js"></script>
</body>
</html>