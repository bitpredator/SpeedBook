<?php
session_start();
require '../connect.php';
if ( $_SESSION['loggedin'] != 1 ) {
  $_SESSION['message'] = "You must log in before viewing your profile page!";
  header("location: ../error.php");
	exit();
}
elseif ( $_SESSION['banned'] != 0 ) {
	$_SESSION['errormessage'] = "You are banned.";
	header("location: ../error.php");
	exit();
}
?>
<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>Your Reports</title>
<script src="http://ajax.googleapis.com/ajax/libs/jquery/1.11.1/jquery.min.js">        </script>
<script src="js/typeahead.min.js"></script>
<?php include 'css/css.html'; ?>
</head>

<body>
	<div class="form">
		<ul class="tab-group">
			<div class="form">  
				<div class="tab-content"> 
					<h1>Pending Reports:</h1><br>
					<table>
        				<thead>
							<tr>
        					<th>Report ID</th>
        					<th>Report Type</th>
        					<th>Comment</th>
							<th>Date</th>
							</tr>
    					<thead>
						<tbody>
					<?php
					$sql = "SELECT * FROM reports WHERE username=:username AND isresolved='0' ORDER BY id desc";
					$stmt = $pdo->prepare($sql);
					$stmt->bindValue(':username', $_SESSION['username']);
					$stmt->execute();
					while ($user = $stmt->fetch(PDO::FETCH_ASSOC)) {
						echo "<tr>";
						echo "<td>";
						echo $user['id'];
						echo "</td>";
									
						echo "<td>";
						echo $user['reporttype'];
						echo "</td>";
						
						echo "<td>";
						echo $user['comment'];
						echo "</td>";
						
						echo "<td>";
						echo $user['date'];
						echo "</td></tr></table>";	
					}
					?>
					
							
							
						<br><h1>Resolved Reports:</h1><br>
						<table>
        				<thead>
							<tr>
        					<th>Report ID</th>
        					<th>Report Type</th>
        					<th>Comment</th>
							<th>Resolution</th>
							<th>View</th>
							</tr>
    					<thead>
						<tbody>
					<?php
					$sql = "SELECT * FROM reports WHERE username=:username AND isresolved='1' ORDER BY id desc";
					$stmt = $pdo->prepare($sql);
					$stmt->bindValue(':username', $_SESSION['username']);
					$stmt->execute();
					while ($user = $stmt->fetch(PDO::FETCH_ASSOC)) {
						$userid = $user['id'];
						echo "<tr>";
						echo "<td>";
						echo $user['id'];
						echo "</td>";
									
						echo "<td>";
						echo $user['reporttype'];
						echo "</td>";
						
						echo "<td>";
						echo $user['comment'];
						echo "</td>";
						
						
						echo "<td>";
						echo $user['resolution'];
						echo "</td>";
						
									
						echo "<td><a href='view-reports-res.php?id=$userid'>View</a>";
						echo "</td></tr>";
					}
					?>
							</table><br>
				</div><!-- end tab-content-->
							<a href="report.php"><button class="button button-block" name="logout"/>Back</button></a>
			</div><!-- end form-->	
				<a href="../dashboard.php"><button class="button button-block" name="logout"/>Dashboard</button></a>
		</ul>	
	</div>
<script src='http://cdnjs.cloudflare.com/ajax/libs/jquery/2.1.3/jquery.min.js'></script>
<script src="js/index.js"></script>
	<script>
    $(document).ready(function(){
    $('input.typeahead').typeahead({
        name: 'typeahead',
        remote:'search.php?key=%QUERY',
        limit : 10
    });
});
    </script>
</body>
</html>