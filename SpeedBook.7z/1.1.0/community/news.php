<?php
session_start();
require '../connect.php';
if ( $_SESSION['loggedin'] != 1 ) {
  $_SESSION['message'] = "You must log in before viewing your profile page!";
  header("location: ../error.php");
	exit();
}
elseif ( $_SESSION['banned'] != 0 ) {
	$_SESSION['errormessage'] = "You are banned.";
	header("location: ../error.php");
	exit();
}
?>
<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>News</title>
<?php include 'css/css.html'; ?>
</head>

<body>
	<div class="form">
		<ul class="tab-group">
			<div class="form">  
				<div class="tab-content"> 
					<h1>Current News:</h1><br>
					<table>
        				<thead>
							<tr>
        					<th>Headline</th>
        					<th>Date</th>
        					<th></th>
							</tr>
    					<thead>
						<tbody>
					<?php
					$sql = "SELECT * FROM news ORDER BY id desc";
					$stmt = $pdo->prepare($sql);
					$stmt->execute();
					while ($user = $stmt->fetch(PDO::FETCH_ASSOC)) {
						$newsid = $user['id'];
						echo "<tr>";
						echo "<td>";
						echo $user['title'];
						echo "</td>";
									
						echo "<td>";
						echo $user['date'];
						echo "</td>";
									
									
						echo "<td><a href='readnews.php?id=$newsid'>Read</a>";
						echo "</td></tr>";
					}
					?>
					</table>
				</div><!-- end tab-content-->		
			</div><!-- end form-->	
				
		</ul>	
	</div>
		<a href="../dashboard.php"><button class="button button-block" name="logout"/>Dashboard</button></a>
<script src='http://cdnjs.cloudflare.com/ajax/libs/jquery/2.1.3/jquery.min.js'></script>
<script src="js/index.js"></script>
</body>
</html>