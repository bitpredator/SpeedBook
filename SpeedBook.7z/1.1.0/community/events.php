<?php
session_start();
require '../connect.php';
if ( $_SESSION['loggedin'] != 1 ) {
  $_SESSION['message'] = "You must log in before viewing events!";
  header("location: ../error.php");
	exit();
}
elseif ( $_SESSION['banned'] != 0 ) {
	$_SESSION['errormessage'] = "You are banned.";
	header("location: ../error.php");
	exit();
}
?>
<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>Event List</title>
<script src="http://ajax.googleapis.com/ajax/libs/jquery/1.11.1/jquery.min.js">        </script>
<script src="js/typeahead.min.js"></script>
<?php include 'css/css.html'; ?>
</head>

<body>
	<div class="form">
		<ul class="tab-group">
			<div class="form">  
				<div class="tab-content">
				<a href="addevent.php"><button title="New Message" target="_self" class="dashlinks dashlinks-block2">New Message</button></a>
					<a href="sent.php"><button title="Sent Messages" target="_self" class="dashlinks dashlinks-block2">Sent Messages</button></a><br><br>
					<h1>Event List</h1><br>
					<table>
        				<thead>
							<tr>
        					<th>Time</th>
        					<th>Game</th>
        					<th>Server</th>
        					<th>Players</th>
							<th></th>
							</tr>
    					<thead>
						<tbody>
					<?php
					$sql = "SELECT * FROM events ORDER BY id desc";
					$stmt = $pdo->prepare($sql);
					$stmt->execute();
					while ($user = $stmt->fetch(PDO::FETCH_ASSOC)) {
						$userid = $user['username'];
						echo "<tr>";
						echo "<td>";
						echo $user['time'];
						echo "</td>";
									
						echo "<td>";
						echo $user['game'];
						echo "</td>";
						
						echo "<td>";
						echo $user['server'];
						echo "</td>";
						
						
						echo "<td>";
						echo $user['players'];
						echo "</td>";
									
						
						echo "<td><a href='../pm/join-event.php?id=$userid'>Join</a>";
						echo "</td>";
						
						echo "<td><a href='../pm/join-event.php?id=$userid'>View</a>";
						echo "</td> </tr>";
					}
					?>
				</div><!-- end tab-content-->		
			</div><!-- end form-->	
				<a href="../dashboard.php"><button class="button button-block" name="logout"/>Dashboard</button></a>
		</ul>	
	</div>
<script src='http://cdnjs.cloudflare.com/ajax/libs/jquery/2.1.3/jquery.min.js'></script>
<script src="js/index.js"></script>
	<script>
    $(document).ready(function(){
    $('input.typeahead').typeahead({
        name: 'typeahead',
        remote:'search.php?key=%QUERY',
        limit : 10
    });
});
    </script>
</body>
</html>