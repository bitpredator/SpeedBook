<?php
session_start();
require '../connect.php';
if ( $_SESSION['loggedin'] != 1 ) {
  $_SESSION['message'] = "You must log in before viewing your profile page!";
  header("location: ../error.php");
	exit();
}
elseif ( $_SESSION['banned'] != 0 ) {
	$_SESSION['errormessage'] = "You are banned.";
	header("location: ../error.php");
	exit();
}
?>
<?php
$newsid=$_REQUEST['id'];
$sql = "SELECT * FROM news WHERE id=:newsid ORDER BY id desc";
    $stmt = $pdo->prepare($sql);
	$stmt->bindValue(':newsid', $newsid);
    $stmt->execute();
    $user = $stmt->fetch(PDO::FETCH_ASSOC);
	$title = $user['title'];
	$submittedby = $user['submittedby'];
	$date = $user['date'];
	$body = $user['body'];

?>
<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title><?= $title ?></title>
<?php include 'css/css.html'; ?>
</head>

<body>
	<div class="form">
		<ul class="tab-group">
			<div class="form">  
				<div class="tab-content"> 
					<h1><?= $title ?></h1><br>
					<center><font color="#D3D3D3">By: <?= $submittedby ?></font><br>
						<font color="#D3D3D3"><i><?= $date ?></i></font><br><br><br></center>
					<p><?= $body ?></p>
				</div><!-- end tab-content-->
				<br><a href="news.php"><button class="button button-block" name="logout"/>Back</button></a>
			</div><!-- end form-->
		</ul>
		<a href="../dashboard.php"><button class="button button-block" name="logout"/>Dashboard</button></a>
	</div>
<script src='http://cdnjs.cloudflare.com/ajax/libs/jquery/2.1.3/jquery.min.js'></script>
<script src="js/index.js"></script>
</body>
</html>