<?php
session_start();

require 'lib/password.php';
require 'connect.php';

if(isset($_POST['login'])){
    
    //Retrieve the field values from our login form.
    $username = !empty($_POST['username']) ? trim($_POST['username']) : null;
    $passwordAttempt = !empty($_POST['password']) ? trim($_POST['password']) : null;
    
    //Retrieve the user account information for the given username.
    $sql = "SELECT id, username, password, adminlevel, moderatorlevel, active, profilesetup, banned FROM users WHERE username = :username";
    $stmt = $pdo->prepare($sql);
    
    //Bind value.
    $stmt->bindValue(':username', $username);
    
    //Execute.
    $stmt->execute();
    
    //Fetch row.
    $user = $stmt->fetch(PDO::FETCH_ASSOC);
    
    //If $row is FALSE.
    if($user === false){
        //Could not find a user with that username!
        //PS: You might want to handle this error in a more user-friendly manner!
        $_SESSION['errormessage'] = 'Incorrect username/password combination.';
		header("location: error.php");
		exit();
        die();
    } else{
        //User account found. Check to see if the given password matches the
        //password hash that we stored in our users table.
        
        //Compare the passwords.
        $validPassword = password_verify($passwordAttempt, $user['password']);
        
        //If $validPassword is TRUE, the login has been successful.
        if($validPassword){
            
            //Provide the user with a login session.
            $_SESSION['user_id'] = $user['id'];
            $_SESSION['logged_in'] = time();
			$_SESSION['adminlevel'] = $user['adminlevel'];
			$_SESSION['active'] = $user['active'];
			$_SESSION['moderatorlevel'] = $user['moderatorlevel'];
			$_SESSION['profilesetup'] = $user['profilesetup'];
			$_SESSION['username'] = $user['username'];
			$_SESSION['loggedin'] = 1;
			$_SESSION['banned'] = $user['banned'];
			
            header('Location: index.php');
			exit();
            exit;
            
        } else{
            //$validPassword was FALSE. Passwords do not match.
            $_SESSION['errormessage'] = 'Passwords do not match.';
		header("location: error.php");
		exit();
        die();
        }
    }
    
}
 
?>
<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>Login</title>
<script type="text/JavaScript" src="js/sha512.js"></script> 
<script type="text/JavaScript" src="js/forms.js"></script>
<?php include 'css/css.html'; ?>
</head>

<body>
	<div class="form">
		<?php
		if ( $_SESSION['banned'] != 0 ) {
			echo "<h1><center>You are banned!</center></h1>";
		}
		else
		{}
		?>
		<ul class="tab-group">
			<div class="form">  
				<div class="tab-content"> 
					 <h1>Login</h1><br><br>
       				 <form action="login.php" method="post">
						 <div class="field-wrap">
            			<label for="username">Username</label>
            			<input type="text" id="username" name="username">
						 </div>
							 <div class="field-wrap">
            			<label for="password">Password</label>
            			<input type="password" id="password" name="password"><br><br>
            			<input type="submit" name="login" value="Login" class="button button button-block">
								 <a href="register.php">Don't have an account? Register here.</a>
						 </div>
        			</form>
				</div><!-- end tab-content-->
			</div><!-- end form-->
		</ul>
	</div>
<script src='http://cdnjs.cloudflare.com/ajax/libs/jquery/2.1.3/jquery.min.js'></script>
<script src="js/index.js"></script>
</body>
</html>