<?php
session_start();
require '../connect.php';
if ( $_SESSION['loggedin'] != 1 ) {
  $_SESSION['message'] = "You must log in before viewing your profile page!";
  header("location: ../error.php");
	exit();
}
elseif ( $_SESSION['banned'] != 0 ) {
	$_SESSION['errormessage'] = "You are banned.";
	header("location: ../error.php");
	exit();
}
?>

<?php
if(isset($_POST['register'])){
	$offence = !empty($_POST['offence']) ? trim($_POST['offence']) : null;
    $damage = !empty($_POST['damage']) ? trim($_POST['damage']) : null;
	$costs = !empty($_POST['costs']) ? trim($_POST['costs']) : null;
	$comment = !empty($_POST['comment']) ? trim($_POST['comment']) : null;

	
	 $sql = "INSERT INTO incidents (offence, damage, costs, comment, date, emp) VALUES (:offence, :damage, :costs, :comment, :date, :emp)";
    $stmt = $pdo->prepare($sql);
    
	$stmt->bindValue(':offence', $offence);
	$stmt->bindValue(':damage', $damage);
	$stmt->bindValue(':costs', $costs);
	$stmt->bindValue(':comment', $comment);
	$stmt->bindValue(':date', date("Y-m-d h:i:s"));
	$stmt->bindValue(':emp', $_SESSION['username']);

    $result = $stmt->execute();
    
    if($result){
		$_SESSION['successmessage'] = 'Incident Successfully Submitted!';
		header("location: ../success.php");
		exit();
    }
	
	else {
		$_SESSION['errormessage'] = 'Incident Log Failed. Fatal Error.';
		header("location: ../error.php");
		exit();
	}
}
?>
<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>Log Offence</title>
<?php include 'css/css.html'; ?>
</head>

<body>
	<div class="form">
		<ul class="tab-group">
			<div class="form">  
				<div class="tab-content"> 
					<form action="incident.php" method="post">
					<h1>Log Incident</h1><br><br>
						 <div class="field-wrap">
			  				<select name="offence" class="field select medium" required class="dropbox">
							<option value="Offence" selected>Select Offence*</option>
							<option value="Red Light">Red Light</option>
							<option value="Speeding">Speeding</option>
							<option value="No Lights">No Lights</option>
							<option value="Accident">Accident</option>
							<option value="Wrong Way">Wrong Way</option>
							<option value="Out of Gas">Out of Gas</option>
							<option value="No Rest/Over Hours">Camp Verde</option>
							<option value="Failure to stop at weigh station">Failure to stop at weigh station</option>
							 </select>
						</div><br>
								
						<div class="field-wrap">
							<label>
							  Damage Percent (if any)<span class="req">*</span>
							</label>
							<input type="number" autocomplete="off" name="damage"/>
						  </div>

						   <div class="field-wrap">
							<label>
							  Violation Cost (if any)<span class="req">*</span>
							</label>
							<input type="number" autocomplete="off" name="costs"/>
						  </div>

						   <div class="field-wrap">
							<label>
							  Comment:
							</label>
							<input type="text" autocomplete="off" name="comment"/>
						  </div>

            <input type="submit" name="register" value="Log Offence" class="button button button-block"></button>
					</form>
				</div><!-- end tab-content-->		
			</div><!-- end form-->	
		<script type="text/javascript">
		  function calc() {
  var i = document.getElementById("profit").value;
  var p = 35;
  var o = (i/100) * p;
  document.getElementById("pay").value = o;
}
		  </script>
				
		</ul>
	<a href="../dashboard.php"><button class="button button-block" name="logout"/>Dashboard</button></a>
	</div>
		
<script src='http://cdnjs.cloudflare.com/ajax/libs/jquery/2.1.3/jquery.min.js'></script>
<script src="js/index.js"></script>
</body>
</html>