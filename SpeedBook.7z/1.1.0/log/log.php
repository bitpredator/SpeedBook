<?php
session_start();
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);
require '../connect.php';
if ( $_SESSION['loggedin'] != 1 ) {
  $_SESSION['message'] = "You must log in before viewing your profile page!";
  header("location: ../error.php");
	exit();
}
elseif ( $_SESSION['banned'] != 0 ) {
	$_SESSION['errormessage'] = "You are banned.";
	header("location: ../error.php");
	exit();
}
?>

<?php
if(isset($_POST['register'])){
	$depcity = !empty($_POST['depcity']) ? trim($_POST['depcity']) : null;
    $arrcity = !empty($_POST['arrcity']) ? trim($_POST['arrcity']) : null;
	$cargo = !empty($_POST['cargo']) ? trim($_POST['cargo']) : null;
	$disdriven = !empty($_POST['disdriven']) ? trim($_POST['disdriven']) : null;
	$fuelcon = !empty($_POST['fuelcon']) ? trim($_POST['fuelcon']) : null;
	$weight = !empty($_POST['profits']) ? trim($_POST['profits']) : null;
	$profits = !empty($_POST['profits']) ? trim($_POST['profits']) : null;
	$paycheck = !empty($_POST['paycheck']) ? trim($_POST['paycheck']) : null;
	$toll = !empty($_POST['toll']) ? trim($_POST['toll']) : null;
	$comment = !empty($_POST['comment']) ? trim($_POST['comment']) : null;
	
	 $sql = "INSERT INTO jobslog (depcity, arrcity, cargo, distance, fuelcon, weight, profits, pay, toll, comment, date, emp) VALUES (:depcity, :arrcity, :cargo, :distance, :fuelcon, :weight, :profits, :pay, :toll, :comment, :date, :emp)";
    $stmt = $pdo->prepare($sql);
    
	$stmt->bindValue(':depcity', $depcity);
	$stmt->bindValue(':arrcity', $arrcity);
	$stmt->bindValue(':cargo', $cargo);
	$stmt->bindValue(':distance', $disdriven);
	$stmt->bindValue(':fuelcon', $fuelcon);
	$stmt->bindValue(':weight', $weight);
	$stmt->bindValue(':profits', $profits);
	$stmt->bindValue(':pay', $paycheck);
	$stmt->bindValue(':toll', $toll);
	$stmt->bindValue(':comment', $comment);
	$stmt->bindValue(':date', date("Y-m-d h:i:s"));
	$stmt->bindValue(':emp', $_SESSION['username']);

    $result = $stmt->execute();
    
    if($result){
    }
	
	$sql = "UPDATE users SET bank = bank + :pay";
    $stmt = $pdo->prepare($sql);
	$stmt->bindValue(':pay', $paycheck);
	$result = $stmt->execute();
	
	if($result){
		$_SESSION['successmessage'] = 'Job Successfully Submitted!';
		header("location: ../success.php");
		exit();
    }
	
	else {
		$_SESSION['errormessage'] = 'Job Log Failed. Fatal Error.';
		header("location: ../error.php");
		exit();
	}
}
?>
<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>Log Job</title>
<?php include 'css/css.html'; ?>
</head>

<body>
	<div class="form">
		<ul class="tab-group">
			<div class="form">  
				<div class="tab-content"> 
					<form action="log.php" method="post">
					<h1>Log Job</h1><br><br>
						 <div class="field-wrap">
			  				<select name="depcity" class="field select medium" required class="dropbox">
							<option value="Departure City" selected>Departure City*</option>
							<option value="--- United States">--- United States</option>
							<option value="-- Arizona">-- Arizona</option>
							<option value="Camp Verde">Camp Verde</option>
							<option value="Ehrenberg">Ehrenberg</option>
							<option value="Flagstaff">Flagstaff</option>
							<option value="Grand Canyon Village">Grand Canyon Village</option>
							<option value="Holbrook">Holbrook</option>
							<option value="Kayenta">Kayenta</option>
							<option value="Kingman">Kingman</option>
							<option value="Nogales">Nogales</option>
							<option value="Page">Page</option>
							<option value="Phoenix">Phoenix</option>
							<option value="San Simon">San Simon</option>
							<option value="Show Low">Show Low</option>
							<option value="Sierra Vista">Sierra Vista</option>
							<option value="Tucson">Tucson</option>
							<option value="Yuma">Yuma</option>
							<option value="Globe">Globe</option>
							<option value=""></option>
							<option value="--- California">--- California</option>
							<option value="Bakersfield">Bakersfield</option>
							<option value="Barstow">Barstow</option>
							<option value="Carlsbad">Carlsbad</option>
							<option value="El Centro">El Centro</option>
							<option value="Eureka">Eureka</option>
							<option value="Fresno">Fresno</option>
							<option value="Hornbrook">Hornbrook</option>
							<option value="Huron">Huron</option>
							<option value="Los Angeles">Los Angeles</option>
							<option value="Oakdale">Oakdale</option>
							<option value="Oakland">Oakland</option>
							<option value="Oxnard">Oxnard</option>
							<option value="Redding">Redding</option>
							<option value="Sacramento">Sacramento</option>
							<option value="San Diego">San Diego</option>
							<option value="San Francisco">San Francisco</option>
							<option value="San Rafael">San Rafael</option>
							<option value="Santa Cruz">Santa Cruz</option>
							<option value="Santa Maria">Santa Maria</option>
							<option value="Stockton">Stockton</option>
							<option value="Truckee">Truckee</option>
							<option value="Ukiah">Ukiah</option>
							<option value=""></option>
							<option value="--- Nevada Edit">--- Nevada Edit</option>
							<option value="Carson City">Carson City</option>
							<option value="Elko">Elko</option>
							<option value="Ely">Ely</option>
							<option value="Jackpot">Jackpot</option>
							<option value="Las Vegas">Las Vegas</option>
							<option value="Pioche">Pioche</option>
							<option value="Primm">Primm</option>
							<option value="Reno">Reno</option>
							<option value="Tonopah">Tonopah</option>
							<option value="Winnemucca">Winnemucca</option>
							<option value=""></option>
							<option value="--- New Mexico">--- New Mexico</option>
							<option value="Albuquerque">Albuquerque</option>
							<option value="Alamogordo">Alamogordo</option>
							<option value="Artesia">Artesia</option>
							<option value="Carrizozo*">Carrizozo*</option>
							<option value="Carlsbad">Carlsbad</option>
							<option value="Clovis">Clovis</option>
							<option value="Corona*">Corona*</option>
							<option value="Eagle Nest*">Eagle Nest*</option>
							<option value="Elida*">Elida*</option>
							<option value="Farmington">Farmington</option>
							<option value="Fort Sumner*">Fort Sumner*</option>
							<option value="Gallup">Gallup</option>
							<option value="Hobbs">Hobbs</option>
							<option value="Las Cruces">Las Cruces</option>
							<option value="Omega*">Omega*</option>
							<option value="Quemado*">Quemado*</option>
							<option value="Raton">Raton</option>
							<option value="Roswell">Roswell</option>
							<option value="Santa Fe">Santa Fe</option>
							<option value="Santa Rosa*">Santa Rosa*</option>
							<option value="Shiprock*">Shiprock*</option>
							<option value="Socorro">Socorro</option>
							<option value="Tucumcari">Tucumcari</option>
							<option value="Vaughn*">Vaughn*</option>
							<option value="--------- ETS ---------">--------- ETS ---------</option>
							<option value=""></option>
							<option value="--- Austria">--- Austria</option>
							<option value="Innsbruck">Innsbruck</option>
							<option value="Linz">Linz</option>
							<option value="Salzburg">Salzburg</option>
							<option value="Vienna (Wien)">Vienna (Wien)</option>
							<option value="Graz">Graz</option>
							<option value="Klagenfurt am Wörthersee">Klagenfurt am Wörthersee</option>
							<option value=""></option>
							<option value="--- Belgium">--- Belgium</option>
							<option value="Brussel">Brussel</option>
							<option value="Liège">Liège</option>
							<option value=""></option>
							<option value="--- Czech Republic">--- Czech Republic</option>
							<option value="Brno">Brno</option>
							<option value="Prague (Praha)">Prague (Praha)</option>
							<option value="Ostrava">Ostrava</option>
							<option value=""></option>
							<option value="--- Denmark">--- Denmark</option>
							<option value="Aalborg">Aalborg</option>
							<option value="Copenhagen (København)">Copenhagen (København)</option>
							<option value="Odense">Odense</option>
							<option value="Esbjerg">Esbjerg</option>
							<option value="Frederikshavn">Frederikshavn</option>
							<option value="Gedser">Gedser</option>
							<option value="Hirtshals">Hirtshals</option>
							<option value=""></option>
							<option value="--- France">--- France</option>
							<option value="Calais">Calais</option>
							<option value="Dijon">Dijon</option>
							<option value="Lille">Lille</option>
							<option value="Lyon">Lyon</option>
							<option value="Metz">Metz</option>
							<option value="Paris">Paris</option>
							<option value="Reims">Reims</option>
							<option value="Strasbourg">Strasbourg</option>
							<option value="Le Havre">Le Havre</option>
							<option value="Le Mans ">Le Mans </option>
							<option value="Clermont-Ferrand ">Clermont-Ferrand </option>
							<option value="Nice ">Nice </option>
							<option value="Marseille ">Marseille </option>
							<option value="Montpellier">Montpellier</option>
							<option value="Toulouse">Toulouse</option>
							<option value="Bordeaux ">Bordeaux </option>
							<option value="La Rochelle">La Rochelle</option>
							<option value="Nantes.">Nantes.</option>
							<option value="Brest">Brest</option>
							<option value="Rennes ">Rennes </option>
							<option value="Limoges">Limoges</option>
							<option value=""></option>
							<option value="-- Towns: 7">-- Towns: 7</option>
							<option value="Paluel">Paluel</option>
							<option value="Saint-Laurent ">Saint-Laurent </option>
							<option value="Bourges ">Bourges </option>
							<option value="Saint-Alban-du-Rhône ">Saint-Alban-du-Rhône </option>
							<option value="Golfech">Golfech</option>
							<option value="Civaux ">Civaux </option>
							<option value="Roscoff ">Roscoff </option>
							<option value=""></option>
							<option value="--- Germany">--- Germany</option>
							<option value="Berlin">Berlin</option>
							<option value="Bremen">Bremen</option>
							<option value="Dortmund">Dortmund</option>
							<option value="Dresden">Dresden</option>
							<option value="Duisburg">Duisburg</option>
							<option value="Düsseldorf">Düsseldorf</option>
							<option value="Erfurt">Erfurt</option>
							<option value="Frankfurt">Frankfurt</option>
							<option value="Hamburg">Hamburg</option>
							<option value="Hannover">Hannover</option>
							<option value="Kassel">Kassel</option>
							<option value="Kiel">Kiel</option>
							<option value="Cologne (Köln)">Cologne (Köln)</option>
							<option value="Leipzig">Leipzig</option>
							<option value="Magdeburg">Magdeburg</option>
							<option value="Mannheim">Mannheim</option>
							<option value="Munich (München)">Munich (München)</option>
							<option value="Nürnberg">Nürnberg</option>
							<option value="Osnabrück">Osnabrück</option>
							<option value="Rostock">Rostock</option>
							<option value="Stuttgart">Stuttgart</option>
							<option value=""></option>
							<option value="--- Hungary">--- Hungary</option>
							<option value="Budapest">Budapest</option>
							<option value="Debrecen">Debrecen</option>
							<option value="Pécs ">Pécs </option>
							<option value="Szeged ">Szeged </option>
							<option value=""></option>
							<option value="--- Italy">--- Italy</option>
							<option value="Milano">Milano</option>
							<option value="Torino">Torino</option>
							<option value="Verona">Verona</option>
							<option value="Venezia ">Venezia </option>
							<option value="Genova">Genova</option>
							<option value="Bologna ">Bologna </option>
							<option value="Livorno">Livorno</option>
							<option value="Ancona ">Ancona </option>
							<option value="Pescara ">Pescara </option>
							<option value="Roma ">Roma </option>
							<option value="Napoli">Napoli</option>
							<option value="Firenze">Firenze</option>
							<option value="Bari ">Bari </option>
							<option value="Taranto ">Taranto </option>
							<option value="Catanzaro ">Catanzaro </option>
							<option value="Parma">Parma</option>
							<option value="Suzzara">Suzzara</option>
							<option value="Terni">Terni</option>
							<option value="Cassino .">Cassino .</option>
							<option value="Villa San Giovanni">Villa San Giovanni</option>
							<option value="Messina ">Messina </option>
							<option value="Catania ">Catania </option>
							<option value="Palermo">Palermo</option>
							<option value=""></option>
							<option value="--- Luxembourg">--- Luxembourg</option>
							<option value="Luxembourg">Luxembourg</option>
							<option value=""></option>
							<option value="--- Netherlands">--- Netherlands</option>
							<option value="Amsterdam">Amsterdam</option>
							<option value="Groningen">Groningen</option>
							<option value="Rotterdam">Rotterdam</option>
							<option value=""></option>
							<option value="--- Norway ">--- Norway </option>
							<option value="Bergen">Bergen</option>
							<option value="Kristiansand">Kristiansand</option>
							<option value="Oslo">Oslo</option>
							<option value="Stavanger">Stavanger</option>
							<option value=""></option>
							<option value="--- Poland">--- Poland</option>
							<option value="Bialystok ">Bialystok </option>
							<option value="Gdańsk">Gdańsk</option>
							<option value="Katowice ">Katowice </option>
							<option value="Kraków ">Kraków </option>
							<option value="Łódź ">Łódź </option>
							<option value="Lublin.">Lublin.</option>
							<option value="Olsztyn ">Olsztyn </option>
							<option value="Poznań">Poznań</option>
							<option value="Szczecin">Szczecin</option>
							<option value="Wrocław">Wrocław</option>
							<option value="Warsaw (Warszawa)">Warsaw (Warszawa)</option>
							<option value=""></option>
							<option value="--- Slovakia">--- Slovakia</option>
							<option value="Banská Bystrica">Banská Bystrica</option>
							<option value="Bratislava">Bratislava</option>
							<option value="Košice">Košice</option>
							<option value=""></option>
							<option value="--- Sweden ">--- Sweden </option>
							<option value="Göteborg">Göteborg</option>
							<option value="Helsingborg">Helsingborg</option>
							<option value="Jönköping">Jönköping</option>
							<option value="Kalmar">Kalmar</option>
							<option value="Karlskrona">Karlskrona</option>
							<option value="Linköping">Linköping</option>
							<option value="Malmö">Malmö</option>
							<option value="Örebro">Örebro</option>
							<option value="Stockholm">Stockholm</option>
							<option value="Uppsala">Uppsala</option>
							<option value="Västerås">Västerås</option>
							<option value="Växjö">Växjö</option>
							<option value="Nynäshamn">Nynäshamn</option>
							<option value="Södertälje">Södertälje</option>
							<option value="Trelleborg">Trelleborg</option>
							<option value=""></option>
							<option value="--- Switzerland">--- Switzerland</option>
							<option value="Bern">Bern</option>
							<option value="Genève">Genève</option>
							<option value="Zürich">Zürich</option>
							<option value=""></option>
							<option value="--- United Kingdom">--- United Kingdom</option>
							<option value="England">England</option>
							<option value="Birmingham">Birmingham</option>
							<option value="Cambridge">Cambridge</option>
							<option value="Carlisle">Carlisle</option>
							<option value="Dover">Dover</option>
							<option value="Felixstowe">Felixstowe</option>
							<option value="Grimsby">Grimsby</option>
							<option value="Liverpool">Liverpool</option>
							<option value="London">London</option>
							<option value="Manchester">Manchester</option>
							<option value="Newcastle-upon-Tyne">Newcastle-upon-Tyne</option>
							<option value="Plymouth">Plymouth</option>
							<option value="Sheffield">Sheffield</option>
							<option value="Southampton">Southampton</option>
							<option value=""></option>
							<option value="--- Scotland">--- Scotland</option>
							<option value="Aberdeen">Aberdeen</option>
							<option value="Edinburgh">Edinburgh</option>
							<option value="Glasgow">Glasgow</option>
							<option value=""></option>
							<option value="--- Wales">--- Wales</option>
							<option value="Cardiff">Cardiff</option>
							<option value="Swansea">Swansea</option>
											</select>
									  </div>
			
						<div class="field-wrap">
			 				<select name="arrcity" class="field select medium" required class="dropbox">
								<option value="Arrival City" selected>Arrival City*</option>
								<option value="--- United States">--- United States</option>
								<option value="-- Arizona">-- Arizona</option>
								<option value="Camp Verde">Camp Verde</option>
								<option value="Ehrenberg">Ehrenberg</option>
								<option value="Flagstaff">Flagstaff</option>
								<option value="Grand Canyon Village">Grand Canyon Village</option>
								<option value="Holbrook">Holbrook</option>
								<option value="Kayenta">Kayenta</option>
								<option value="Kingman">Kingman</option>
								<option value="Nogales">Nogales</option>
								<option value="Page">Page</option>
								<option value="Phoenix">Phoenix</option>
								<option value="San Simon">San Simon</option>
								<option value="Show Low">Show Low</option>
								<option value="Sierra Vista">Sierra Vista</option>
								<option value="Tucson">Tucson</option>
								<option value="Yuma">Yuma</option>
								<option value="Globe">Globe</option>
								<option value=""></option>
								<option value="--- California">--- California</option>
								<option value="Bakersfield">Bakersfield</option>
								<option value="Barstow">Barstow</option>
								<option value="Carlsbad">Carlsbad</option>
								<option value="El Centro">El Centro</option>
								<option value="Eureka">Eureka</option>
								<option value="Fresno">Fresno</option>
								<option value="Hornbrook">Hornbrook</option>
								<option value="Huron">Huron</option>
								<option value="Los Angeles">Los Angeles</option>
								<option value="Oakdale">Oakdale</option>
								<option value="Oakland">Oakland</option>
								<option value="Oxnard">Oxnard</option>
								<option value="Redding">Redding</option>
								<option value="Sacramento">Sacramento</option>
								<option value="San Diego">San Diego</option>
								<option value="San Francisco">San Francisco</option>
								<option value="San Rafael">San Rafael</option>
								<option value="Santa Cruz">Santa Cruz</option>
								<option value="Santa Maria">Santa Maria</option>
								<option value="Stockton">Stockton</option>
								<option value="Truckee">Truckee</option>
								<option value="Ukiah">Ukiah</option>
								<option value=""></option>
								<option value="--- Nevada Edit">--- Nevada Edit</option>
								<option value="Carson City">Carson City</option>
								<option value="Elko">Elko</option>
								<option value="Ely">Ely</option>
								<option value="Jackpot">Jackpot</option>
								<option value="Las Vegas">Las Vegas</option>
								<option value="Pioche">Pioche</option>
								<option value="Primm">Primm</option>
								<option value="Reno">Reno</option>
								<option value="Tonopah">Tonopah</option>
								<option value="Winnemucca">Winnemucca</option>
								<option value=""></option>
								<option value="--- New Mexico">--- New Mexico</option>
								<option value="Albuquerque">Albuquerque</option>
								<option value="Alamogordo">Alamogordo</option>
								<option value="Artesia">Artesia</option>
								<option value="Carrizozo*">Carrizozo*</option>
								<option value="Carlsbad">Carlsbad</option>
								<option value="Clovis">Clovis</option>
								<option value="Corona*">Corona*</option>
								<option value="Eagle Nest*">Eagle Nest*</option>
								<option value="Elida*">Elida*</option>
								<option value="Farmington">Farmington</option>
								<option value="Fort Sumner*">Fort Sumner*</option>
								<option value="Gallup">Gallup</option>
								<option value="Hobbs">Hobbs</option>
								<option value="Las Cruces">Las Cruces</option>
								<option value="Omega*">Omega*</option>
								<option value="Quemado*">Quemado*</option>
								<option value="Raton">Raton</option>
								<option value="Roswell">Roswell</option>
								<option value="Santa Fe">Santa Fe</option>
								<option value="Santa Rosa*">Santa Rosa*</option>
								<option value="Shiprock*">Shiprock*</option>
								<option value="Socorro">Socorro</option>
								<option value="Tucumcari">Tucumcari</option>
								<option value="Vaughn*">Vaughn*</option>
								<option value="--------- ETS ---------">--------- ETS ---------</option>
								<option value=""></option>
								<option value="--- Austria">--- Austria</option>
								<option value="Innsbruck">Innsbruck</option>
								<option value="Linz">Linz</option>
								<option value="Salzburg">Salzburg</option>
								<option value="Vienna (Wien)">Vienna (Wien)</option>
								<option value="Graz">Graz</option>
								<option value="Klagenfurt am Wörthersee">Klagenfurt am Wörthersee</option>
								<option value=""></option>
								<option value="--- Belgium">--- Belgium</option>
								<option value="Brussel">Brussel</option>
								<option value="Liège">Liège</option>
								<option value=""></option>
								<option value="--- Czech Republic">--- Czech Republic</option>
								<option value="Brno">Brno</option>
								<option value="Prague (Praha)">Prague (Praha)</option>
								<option value="Ostrava">Ostrava</option>
								<option value=""></option>
								<option value="--- Denmark">--- Denmark</option>
								<option value="Aalborg">Aalborg</option>
								<option value="Copenhagen (København)">Copenhagen (København)</option>
								<option value="Odense">Odense</option>
								<option value="Esbjerg">Esbjerg</option>
								<option value="Frederikshavn">Frederikshavn</option>
								<option value="Gedser">Gedser</option>
								<option value="Hirtshals">Hirtshals</option>
								<option value=""></option>
								<option value="--- France">--- France</option>
								<option value="Calais">Calais</option>
								<option value="Dijon">Dijon</option>
								<option value="Lille">Lille</option>
								<option value="Lyon">Lyon</option>
								<option value="Metz">Metz</option>
								<option value="Paris">Paris</option>
								<option value="Reims">Reims</option>
								<option value="Strasbourg">Strasbourg</option>
								<option value="Le Havre">Le Havre</option>
								<option value="Le Mans ">Le Mans </option>
								<option value="Clermont-Ferrand ">Clermont-Ferrand </option>
								<option value="Nice ">Nice </option>
								<option value="Marseille ">Marseille </option>
								<option value="Montpellier">Montpellier</option>
								<option value="Toulouse">Toulouse</option>
								<option value="Bordeaux ">Bordeaux </option>
								<option value="La Rochelle">La Rochelle</option>
								<option value="Nantes.">Nantes.</option>
								<option value="Brest">Brest</option>
								<option value="Rennes ">Rennes </option>
								<option value="Limoges">Limoges</option>
								<option value=""></option>
								<option value="-- Towns: 7">-- Towns: 7</option>
								<option value="Paluel">Paluel</option>
								<option value="Saint-Laurent ">Saint-Laurent </option>
								<option value="Bourges ">Bourges </option>
								<option value="Saint-Alban-du-Rhône ">Saint-Alban-du-Rhône </option>
								<option value="Golfech">Golfech</option>
								<option value="Civaux ">Civaux </option>
								<option value="Roscoff ">Roscoff </option>
								<option value=""></option>
								<option value="--- Germany">--- Germany</option>
								<option value="Berlin">Berlin</option>
								<option value="Bremen">Bremen</option>
								<option value="Dortmund">Dortmund</option>
								<option value="Dresden">Dresden</option>
								<option value="Duisburg">Duisburg</option>
								<option value="Düsseldorf">Düsseldorf</option>
								<option value="Erfurt">Erfurt</option>
								<option value="Frankfurt">Frankfurt</option>
								<option value="Hamburg">Hamburg</option>
								<option value="Hannover">Hannover</option>
								<option value="Kassel">Kassel</option>
								<option value="Kiel">Kiel</option>
								<option value="Cologne (Köln)">Cologne (Köln)</option>
								<option value="Leipzig">Leipzig</option>
								<option value="Magdeburg">Magdeburg</option>
								<option value="Mannheim">Mannheim</option>
								<option value="Munich (München)">Munich (München)</option>
								<option value="Nürnberg">Nürnberg</option>
								<option value="Osnabrück">Osnabrück</option>
								<option value="Rostock">Rostock</option>
								<option value="Stuttgart">Stuttgart</option>
								<option value=""></option>
								<option value="--- Hungary">--- Hungary</option>
								<option value="Budapest">Budapest</option>
								<option value="Debrecen">Debrecen</option>
								<option value="Pécs ">Pécs </option>
								<option value="Szeged ">Szeged </option>
								<option value=""></option>
								<option value="--- Italy">--- Italy</option>
								<option value="Milano">Milano</option>
								<option value="Torino">Torino</option>
								<option value="Verona">Verona</option>
								<option value="Venezia ">Venezia </option>
								<option value="Genova">Genova</option>
								<option value="Bologna ">Bologna </option>
								<option value="Livorno">Livorno</option>
								<option value="Ancona ">Ancona </option>
								<option value="Pescara ">Pescara </option>
								<option value="Roma ">Roma </option>
								<option value="Napoli">Napoli</option>
								<option value="Firenze">Firenze</option>
								<option value="Bari ">Bari </option>
								<option value="Taranto ">Taranto </option>
								<option value="Catanzaro ">Catanzaro </option>
								<option value="Parma">Parma</option>
								<option value="Suzzara">Suzzara</option>
								<option value="Terni">Terni</option>
								<option value="Cassino .">Cassino .</option>
								<option value="Villa San Giovanni">Villa San Giovanni</option>
								<option value="Messina ">Messina </option>
								<option value="Catania ">Catania </option>
								<option value="Palermo">Palermo</option>
								<option value=""></option>
								<option value="--- Luxembourg">--- Luxembourg</option>
								<option value="Luxembourg">Luxembourg</option>
								<option value=""></option>
								<option value="--- Netherlands">--- Netherlands</option>
								<option value="Amsterdam">Amsterdam</option>
								<option value="Groningen">Groningen</option>
								<option value="Rotterdam">Rotterdam</option>
								<option value=""></option>
								<option value="--- Norway ">--- Norway </option>
								<option value="Bergen">Bergen</option>
								<option value="Kristiansand">Kristiansand</option>
								<option value="Oslo">Oslo</option>
								<option value="Stavanger">Stavanger</option>
								<option value=""></option>
								<option value="--- Poland">--- Poland</option>
								<option value="Bialystok ">Bialystok </option>
								<option value="Gdańsk">Gdańsk</option>
								<option value="Katowice ">Katowice </option>
								<option value="Kraków ">Kraków </option>
								<option value="Łódź ">Łódź </option>
								<option value="Lublin.">Lublin.</option>
								<option value="Olsztyn ">Olsztyn </option>
								<option value="Poznań">Poznań</option>
								<option value="Szczecin">Szczecin</option>
								<option value="Wrocław">Wrocław</option>
								<option value="Warsaw (Warszawa)">Warsaw (Warszawa)</option>
								<option value=""></option>
								<option value="--- Slovakia">--- Slovakia</option>
								<option value="Banská Bystrica">Banská Bystrica</option>
								<option value="Bratislava">Bratislava</option>
								<option value="Košice">Košice</option>
								<option value=""></option>
								<option value="--- Sweden ">--- Sweden </option>
								<option value="Göteborg">Göteborg</option>
								<option value="Helsingborg">Helsingborg</option>
								<option value="Jönköping">Jönköping</option>
								<option value="Kalmar">Kalmar</option>
								<option value="Karlskrona">Karlskrona</option>
								<option value="Linköping">Linköping</option>
								<option value="Malmö">Malmö</option>
								<option value="Örebro">Örebro</option>
								<option value="Stockholm">Stockholm</option>
								<option value="Uppsala">Uppsala</option>
								<option value="Västerås">Västerås</option>
								<option value="Växjö">Växjö</option>
								<option value="Nynäshamn">Nynäshamn</option>
								<option value="Södertälje">Södertälje</option>
								<option value="Trelleborg">Trelleborg</option>
								<option value=""></option>
								<option value="--- Switzerland">--- Switzerland</option>
								<option value="Bern">Bern</option>
								<option value="Genève">Genève</option>
								<option value="Zürich">Zürich</option>
								<option value=""></option>
								<option value="--- United Kingdom">--- United Kingdom</option>
								<option value="England">England</option>
								<option value="Birmingham">Birmingham</option>
								<option value="Cambridge">Cambridge</option>
								<option value="Carlisle">Carlisle</option>
								<option value="Dover">Dover</option>
								<option value="Felixstowe">Felixstowe</option>
								<option value="Grimsby">Grimsby</option>
								<option value="Liverpool">Liverpool</option>
								<option value="London">London</option>
								<option value="Manchester">Manchester</option>
								<option value="Newcastle-upon-Tyne">Newcastle-upon-Tyne</option>
								<option value="Plymouth">Plymouth</option>
								<option value="Sheffield">Sheffield</option>
								<option value="Southampton">Southampton</option>
								<option value=""></option>
								<option value="--- Scotland">--- Scotland</option>
								<option value="Aberdeen">Aberdeen</option>
								<option value="Edinburgh">Edinburgh</option>
								<option value="Glasgow">Glasgow</option>
								<option value=""></option>
								<option value="--- Wales">--- Wales</option>
								<option value="Cardiff">Cardiff</option>
								<option value="Swansea">Swansea</option>
												</select>
										  </div>
						
						<div class="field-wrap">
							<label>
							  Cargo<span class="req">*</span>
							</label>
							<input type="text" required autocomplete="off" name="cargo"/>
						  </div>

						   <div class="field-wrap">
							<label>
							  Distance Driven<span class="req">*</span>
							</label>
							<input type="number" required autocomplete="off" name="disdriven"/>
						  </div>

						   <div class="field-wrap">
							<label>
							  Fuel Consumption (L)<span class="req">*</span>
							</label>
							<input type="number" required autocomplete="off" name="fuelcon"/>
						  </div>

						  <div class="field-wrap">
							<label>
							  Weight (Ton)<span class="req">*</span>
							</label>
							<input type="number" required autocomplete="off" name="weight"/>
						  </div>

						  <div class="field-wrap">
							<label>
							  Profits ($)<span class="req">*</span>
							</label>
							<input type="number" required autocomplete="off" name="profits" onkeyup="calc();" id="profit"/>
						  </div>


						<font color="white">Your Pay</font><span class="req">*</span>
						  <div class="field-wrap">
							<label>
							</label>
							<input type="text" required autocomplete="off" name="paycheck" onkeyup="calc();" value="" readonly id="pay"/>
						  </div>

						  <div class="field-wrap">
							<label>
							  Toll ($)<span class="req">*</span>
							</label>
							<input type="number" required autocomplete="off" name="toll"/>
						  </div>

						  <div class="field-wrap">
							<label>
							  Comments
							</label>
							<input type="text" autocomplete="off" name="comment"/>
						  </div>

            <input type="submit" name="register" value="Log Job" class="button button button-block"></button>
					</form>
				</div><!-- end tab-content-->		
			</div><!-- end form-->	
		<script type="text/javascript">
		  function calc() {
  var i = document.getElementById("profit").value;
  var p = 35;
  var o = (i/100) * p;
  document.getElementById("pay").value = o;
}
		  </script>
				
		</ul>
	<a href="../dashboard.php"><button class="button button-block" name="logout"/>Dashboard</button></a>
	</div>
		
<script src='http://cdnjs.cloudflare.com/ajax/libs/jquery/2.1.3/jquery.min.js'></script>
<script src="js/index.js"></script>
</body>
</html>