<?php
require 'connect.php';
session_start();

if ( $_SESSION['loggedin'] != 1 ) {
  header("location: login.php");
	exit();
}
elseif ( $_SESSION['profilesetup'] == "0" ) {
	header("location: profilesetup.php");
	exit();
	
}
else{
	header("location: dashboard.php");
		exit();
}


?>
<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>Secure Login Error!</title>
<script type="text/JavaScript" src="js/sha512.js"></script> 
<script type="text/JavaScript" src="js/forms.js"></script>
<?php include 'css/css.html'; ?>
</head>

<body>
	<div class="form">
		<ul class="tab-group">
			<div class="form">  
				<div class="tab-content"> 

				</div><!-- end tab-content-->
			</div><!-- end form-->
		</ul>
	</div>
<script src='http://cdnjs.cloudflare.com/ajax/libs/jquery/2.1.3/jquery.min.js'></script>
<script src="js/index.js"></script>
</body>
</html>