<?php
session_start();
require '../connect.php';
if ( $_SESSION['loggedin'] != 1 ) {
  $_SESSION['message'] = "You must log in before viewing your profile page!";
  header("location: ../error.php");
	exit();
}
elseif ( $_SESSION['banned'] != 0 ) {
	$_SESSION['errormessage'] = "You are banned.";
	header("location: ../error.php");
	exit();
}
?>
<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>Inbox</title>
<script type="text/JavaScript" src="js/sha512.js"></script> 
<script type="text/JavaScript" src="js/forms.js"></script>
<?php include 'css/css.html'; ?>
</head>

<body>
	<div class="form">
		<ul class="tab-group">
			<div class="form">  
				<div class="tab-content"> 
					
				</div><!-- end tab-content-->
				<a href="../dashboard.php"><button class="button button-block" name="logout"/>back</button></a>
			</div><!-- end form-->
		</ul>
		<a href="../dashboard.php"><button class="button button-block" name="logout"/>Dashboard</button></a>
	</div>
<script src='http://cdnjs.cloudflare.com/ajax/libs/jquery/2.1.3/jquery.min.js'></script>
<script src="js/index.js"></script>
</body>
</html>