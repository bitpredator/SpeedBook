-- phpMyAdmin SQL Dump
-- version 4.0.10.14
-- http://www.phpmyadmin.net
--
-- Host: localhost:3306
-- Generation Time: Jan 28, 2018 at 09:15 PM
-- Server version: 10.0.30-MariaDB-cll-lve
-- PHP Version: 5.6.20

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `picmoun2_vtc`
--

-- --------------------------------------------------------

--
-- Table structure for table `announcements`
--

CREATE TABLE IF NOT EXISTS `announcements` (
  `id` int(2) NOT NULL AUTO_INCREMENT,
  `anntitle` varchar(200) NOT NULL,
  `annmessage` varchar(200) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=7 ;

--
-- Dumping data for table `announcements`
--

INSERT INTO `announcements` (`id`, `anntitle`, `annmessage`) VALUES
(6, 'Dont forget!', 'Make sure you delete setup.php, and db.sql. Otherwise youre at risk. -- You can delete this announcement in your admin panel.');

-- --------------------------------------------------------

--
-- Table structure for table `City`
--

CREATE TABLE IF NOT EXISTS `City` (
  `t_id` int(11) NOT NULL AUTO_INCREMENT,
  `fk_id` varchar(30) NOT NULL,
  PRIMARY KEY (`t_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `incidents`
--

CREATE TABLE IF NOT EXISTS `incidents` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `offence` varchar(20) NOT NULL,
  `damage` int(4) NOT NULL,
  `costs` varchar(7) NOT NULL,
  `emp` varchar(45) NOT NULL,
  `comment` varchar(200) NOT NULL,
  `date` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=5 ;

-- --------------------------------------------------------

--
-- Table structure for table `jobslog`
--

CREATE TABLE IF NOT EXISTS `jobslog` (
  `id` int(5) NOT NULL AUTO_INCREMENT,
  `depcity` varchar(35) NOT NULL,
  `arrcity` varchar(35) NOT NULL,
  `cargo` varchar(45) NOT NULL,
  `fuelcon` int(20) NOT NULL,
  `weight` int(32) NOT NULL,
  `profits` int(15) NOT NULL,
  `toll` int(10) NOT NULL,
  `comment` varchar(200) NOT NULL,
  `emp` varchar(45) NOT NULL,
  `pay` int(10) NOT NULL,
  `date` datetime NOT NULL,
  `distance` int(6) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=4 ;

-- --------------------------------------------------------

--
-- Table structure for table `maintenance`
--

CREATE TABLE IF NOT EXISTS `maintenance` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `repaircosts` int(7) NOT NULL,
  `fuelcosts` int(7) NOT NULL,
  `comment` varchar(200) NOT NULL,
  `emp` varchar(45) NOT NULL,
  `date` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=4 ;

-- --------------------------------------------------------

--
-- Table structure for table `news`
--

CREATE TABLE IF NOT EXISTS `news` (
  `id` int(6) NOT NULL AUTO_INCREMENT,
  `title` varchar(200) NOT NULL,
  `body` varchar(500) NOT NULL,
  `submittedby` varchar(45) NOT NULL,
  `date` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=5 ;

-- --------------------------------------------------------

--
-- Table structure for table `pm`
--

CREATE TABLE IF NOT EXISTS `pm` (
  `id` int(6) NOT NULL AUTO_INCREMENT,
  `sender` varchar(45) NOT NULL,
  `recipient` varchar(45) NOT NULL,
  `subject` varchar(30) NOT NULL,
  `message` varchar(200) NOT NULL,
  `isread` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=12 ;

-- --------------------------------------------------------

--
-- Table structure for table `reports`
--

CREATE TABLE IF NOT EXISTS `reports` (
  `id` int(6) NOT NULL AUTO_INCREMENT,
  `username` varchar(45) NOT NULL,
  `modname` varchar(45) NOT NULL,
  `reporttype` varchar(50) NOT NULL,
  `comment` varchar(200) NOT NULL,
  `resolution` varchar(200) NOT NULL,
  `date` datetime NOT NULL,
  `isresolved` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=3 ;

-- --------------------------------------------------------

--
-- Table structure for table `secure_login`
--

CREATE TABLE IF NOT EXISTS `secure_login` (
  `user_id` int(11) NOT NULL,
  `time` varchar(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `States`
--

CREATE TABLE IF NOT EXISTS `States` (
  `s_id` int(11) NOT NULL AUTO_INCREMENT,
  `states` varchar(20) NOT NULL,
  PRIMARY KEY (`s_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=23 ;

--
-- Dumping data for table `States`
--

INSERT INTO `States` (`s_id`, `states`) VALUES
(1, 'Arizona'),
(2, 'California'),
(3, 'Nevada'),
(4, 'New Mexico'),
(5, 'Austria'),
(6, 'Belgium'),
(7, 'Czech Republic'),
(8, 'Denmark'),
(9, 'France'),
(10, 'Germany'),
(11, 'Hungary'),
(12, 'Italy'),
(13, 'Luxembourg'),
(14, 'Netherlands'),
(15, 'Norway'),
(16, 'Poland'),
(17, 'Slovakia'),
(18, 'Sweden'),
(19, 'Switzerland'),
(20, 'England'),
(21, 'Scotland'),
(22, 'Wales');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE IF NOT EXISTS `users` (
  `id` int(20) NOT NULL AUTO_INCREMENT,
  `firstname` varchar(200) NOT NULL,
  `lastname` varchar(200) NOT NULL,
  `email` varchar(200) NOT NULL,
  `password` varchar(200) NOT NULL,
  `truckersmpurl` varchar(200) NOT NULL,
  `steam64id` varchar(200) NOT NULL,
  `steamurl` varchar(200) NOT NULL,
  `adminlevel` varchar(200) NOT NULL DEFAULT '0',
  `discord` varchar(200) NOT NULL,
  `other1` varchar(200) NOT NULL,
  `other2` varchar(200) NOT NULL,
  `bank` varchar(200) NOT NULL DEFAULT '0',
  `totaldeliveries` varchar(200) NOT NULL DEFAULT '0',
  `totalkms` varchar(200) NOT NULL DEFAULT '0',
  `totaloffences` varchar(200) NOT NULL DEFAULT '0',
  `userlevel` varchar(200) NOT NULL DEFAULT 'Trucker',
  `active` varchar(200) NOT NULL DEFAULT '0',
  `username` varchar(200) NOT NULL,
  `moderatorlevel` varchar(200) NOT NULL DEFAULT '0',
  `skype` varchar(200) NOT NULL,
  `moto` varchar(200) NOT NULL,
  `regdate` date NOT NULL,
  `preftruck` varchar(200) NOT NULL,
  `avatar` varchar(200) NOT NULL,
  `profilesetup` tinyint(1) NOT NULL DEFAULT '0',
  `banned` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `username` (`username`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=20 ;

-- --------------------------------------------------------

--
-- Table structure for table `vtcinformation`
--

CREATE TABLE IF NOT EXISTS `vtcinformation` (
  `id` int(2) NOT NULL AUTO_INCREMENT,
  `vtcname` varchar(200) NOT NULL,
  `vtcwebsite` varchar(200) NOT NULL,
  `vtcowner` varchar(200) NOT NULL,
  `vtcats` varchar(200) NOT NULL,
  `vtcets` varchar(200) NOT NULL,
  `firsttimerun` varchar(200) NOT NULL DEFAULT 'yes',
  `regopen` varchar(3) NOT NULL DEFAULT 'yes',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=4 ;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
