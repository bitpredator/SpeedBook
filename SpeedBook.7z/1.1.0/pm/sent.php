<?php
session_start();
require '../connect.php';
if ( $_SESSION['loggedin'] != 1 ) {
  $_SESSION['message'] = "You must log in before viewing your profile page!";
  header("location: ../error.php");
	exit();
}
elseif ( $_SESSION['banned'] != 0 ) {
	$_SESSION['errormessage'] = "You are banned.";
	header("location: ../error.php");
	exit();
}
$sql = "SELECT * FROM pm WHERE sender=:me ORDER BY id desc";
    $stmt = $pdo->prepare($sql);
	$stmt->bindValue(':me', $_SESSION['username']);
    $stmt->execute();
    $user = $stmt->fetch(PDO::FETCH_ASSOC);
	$sender = $user['sender'];
	$subject = $user['subject'];
	$id = $user['id'];

?>
<?php
$sql = "SELECT * FROM pm WHERE sender=:me AND isread='1' ORDER BY id desc";
    $stmt = $pdo->prepare($sql);
	$stmt->bindValue(':me', $_SESSION['username']);
    $stmt->execute();
    $user = $stmt->fetch(PDO::FETCH_ASSOC);
	$senderread = $user['sender'];
	$subjectread = $user['subject'];
	$idread = $user['id'];

?>
<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>Sent</title>
<?php include '../css/css.html'; ?>
</head>

<body>
	<div class="form">
		<ul class="tab-group">
			<div class="form">  
				<div class="tab-content"> 
					<h1>Sent Messages:</h1><br>
					<table>
        				<thead>
							<tr>
        					<th>ID</th>
        					<th>Sender</th>
        					<th>Subject</th>
							<th></th>
							</tr>
    					<thead>
						<tbody>
							<?php
							if($id > 0){
								echo "<tr>";
								echo "<td>$id</td>";
								echo "<td>$sender</td>";
								echo "<td>$subject</td>";
								echo "<td><a href='read.php?id=$id'>Read Message</a>";
								echo "</tr>";
								}
							else
							{}
							?>
						</tbody>
					</table>
					<br><a href="view-messages.php"><button class="button button-block" name="logout"/>Back</button></a>
				</div><!-- end tab-content-->
			</div><!-- end form-->
		<br><a href="../dashboard.php"><button class="button button-block" name="logout"/>Dashboard</button></a>
		</ul>
	</div>
<script src='http://cdnjs.cloudflare.com/ajax/libs/jquery/2.1.3/jquery.min.js'></script>
<script src="js/index.js"></script>
</body>
</html>