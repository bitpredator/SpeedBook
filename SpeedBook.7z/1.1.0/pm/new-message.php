<?php
session_start();
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);
require '../connect.php';
$msgid=$_REQUEST['id'];
if ( $_SESSION['loggedin'] != 1 ) {
  $_SESSION['message'] = "You must log in before viewing your profile page!";
  header("location: ../error.php");
	exit();
}
elseif ( $_SESSION['banned'] != 0 ) {
	$_SESSION['errormessage'] = "You are banned.";
	header("location: ../error.php");
	exit();
}
?>
<?php
if(isset($_POST['submit'])){
	$recipient = !empty($_POST['sender']) ? trim($_POST['sender']) : null;
	
	$sql = "SELECT COUNT(username) AS num FROM users WHERE username = :username";
    $stmt = $pdo->prepare($sql);
    
    //Bind the provided username to our prepared statement.
    $stmt->bindValue(':username', $recipient);
    
    //Execute.
    $stmt->execute();
    
    //Fetch the row.
    $row = $stmt->fetch(PDO::FETCH_ASSOC);
    
    //If the provided username already exists - display error.
    //TO ADD - Your own method of handling this error. For example purposes,
    //I'm just going to kill the script completely, as error handling is outside
    //the scope of this tutorial.
    if($row['num'] < 0){
		$_SESSION['errormessage'] = 'No user with that username was found!';
		header("location: ../error.php");
		exit();
        die();
    }
	
	$subject2 = !empty($_POST['subject']) ? trim($_POST['subject']) : null;
	$message2 = !empty($_POST['message']) ? trim($_POST['message']) : null;
	$recipient = !empty($_POST['sender']) ? trim($_POST['sender']) : null;
	
    $sql = "INSERT INTO pm (sender, recipient, subject, message) VALUES (:sender2, :recipient2, :subject2, :message2)";
    $stmt = $pdo->prepare($sql);
	
	$stmt->bindValue(':sender2', $_SESSION['username']);
	$stmt->bindValue(':recipient2', $recipient);
	$stmt->bindValue(':subject2', $subject2);
	$stmt->bindValue(':message2', $message2);
	
	$result = $stmt->execute();
    
    //If the signup process is successful.
    if($result){
        //What you do here is up to you!
		$message = 'Message Sent!';

    echo "<SCRIPT type='text/javascript'> //not showing me this
        alert('$message');
        window.location.replace(\"view-messages.php\");
    </SCRIPT>";
    }
	else {
		$_SESSION['errormessage'] = 'Failed to send message.';
		header("location: ../error.php");
		exit();
	}
}
?>
<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>New Message</title>
<?php include '../css/css.html'; ?>
</head>

<body>
	<div class="form">
		<ul class="tab-group">
			<div class="form">  
				<div class="tab-content"> 
					<form action="new-message.php" method="post">
						 <div class="field-wrap">
            				<font color="white">To</font>
            				<input type="text" id="sender" name="sender" value="<?= $msgid ?>">
						 </div>
						<div class="field-wrap">
							<br><font color="white">Subject</font>
            				<input type="text" id="subject" name="subject" value="">
						 </div>
						<div class="field-wrap">
							<br><font color="white">Message</font>
            				<textarea id="message" name="message" cols="25" rows="7" class="messagebox"></textarea>
						 </div>
						 </div>
						<input type="submit" name="submit" value="submit" class="button button button-block">
        			</form>
					<br><a href="view-messages.php"><button class="button button-block" name="logout"/>Back</button></a>
				</div><!-- end tab-content-->
		  		<br><a href="../dashboard.php"><button class="button button-block" name="logout"/>Dashboard</button></a>
			</div><!-- end form-->
		</ul>
	</div>
<script src='http://cdnjs.cloudflare.com/ajax/libs/jquery/2.1.3/jquery.min.js'></script>
<script src="js/index.js"></script>
</body>
</html>