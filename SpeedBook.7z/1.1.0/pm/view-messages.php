<?php
session_start();
require '../connect.php';
if ( $_SESSION['loggedin'] != 1 ) {
  $_SESSION['message'] = "You must log in before viewing your profile page!";
  header("location: ../error.php");
	exit();
}
elseif ( $_SESSION['banned'] != 0 ) {
	$_SESSION['errormessage'] = "You are banned.";
	header("location: ../error.php");
	exit();
}

$sql = "SELECT * FROM pm WHERE recipient=:me AND isread='0' ORDER BY id desc";
    $stmt = $pdo->prepare($sql);
	$stmt->bindValue(':me', $_SESSION['username']);
    $stmt->execute();
    $user = $stmt->fetch(PDO::FETCH_ASSOC);
	$sender = $user['sender'];
	$subject = $user['subject'];
	$id = $user['id'];

?>
<?php
$sql = "SELECT * FROM pm WHERE recipient=:me AND isread='1' ORDER BY id desc";
    $stmt = $pdo->prepare($sql);
	$stmt->bindValue(':me', $_SESSION['username']);
    $stmt->execute();
    $user = $stmt->fetch(PDO::FETCH_ASSOC);
	$senderread = $user['sender'];
	$subjectread = $user['subject'];
	$idread = $user['id'];

?>
<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>Inbox</title>
<?php include '../css/css.html'; ?>
</head>

<body>
	<div class="form">
		<ul class="tab-group">
			<div class="form">  
				<div class="tab-content"> 
					<a href="new-message.php"><button title="New Message" target="_self" class="dashlinks dashlinks-block2">New Message</button></a>
					<a href="sent.php"><button title="Sent Messages" target="_self" class="dashlinks dashlinks-block2">Sent Messages</button></a><br><br>
					<h1>Unread Messages:</h1><br>
					<table>
        				<thead>
							<tr>
        					<th>ID</th>
        					<th>Sender</th>
        					<th>Subject</th>
							<th></th>
							</tr>
    					<thead>
						<tbody>
							<?php
								
								$sender = $user['sender'];
								$subject = $user['subject'];
								$sql = "SELECT * FROM pm WHERE recipient=:me AND isread='0' ORDER BY id desc";
								$stmt = $pdo->prepare($sql);
								$stmt->bindValue(':me', $_SESSION['username']);
    							$stmt->execute();
    							while ($user = $stmt->fetch(PDO::FETCH_ASSOC)) {
									$mailid = $user['id'];
								echo "<tr>";
								echo "<td>";
								echo $user['id'];
								echo "</td>";
									
								echo "<td>";
								echo $user['sender'];
								echo "</td>";
									
								echo "<td>";
								echo $user['subject'];
								echo "</td>";
									
								echo "<td><a href='read.php?id=$mailid'>Read Message</a>";
								echo "</td></tr>";
								
									
								}
							?>
						</tbody>
					</table><br><br>
					<h1>Read Messages:</h1><br>
					<table>
        				<thead>
							<tr>
        					<th>ID</th>
        					<th>Sender</th>
        					<th>Subject</th>
							<th></th>
							<th></th>
							</tr>
    					<thead>
						<tbody>
							<?php
								$sender = $user['sender'];
								$subject = $user['subject'];
								$sql = "SELECT * FROM pm WHERE recipient=:me AND isread='1' ORDER BY id desc";
								$stmt = $pdo->prepare($sql);
								$stmt->bindValue(':me', $_SESSION['username']);
    							$stmt->execute();
    							while ($user = $stmt->fetch(PDO::FETCH_ASSOC)) {
								$idd = $user['id'];
								echo "<tr>";
								echo "<td>";
								echo $user['id'];
								echo "</td>";
									
								echo "<td>";
								echo $user['sender'];
								echo "</td>";
									
								echo "<td>";
								echo $user['subject'];
								echo "</td>";
									
								echo "<td><a href='read.php?id=$idd'>Read Message</a>";
								echo "</td>";
								
								echo "<td><a href='delete.php?id=$idd'>Delete</a>";
								echo "</td></tr>";
								}
							?>
						</tbody>
					</table>
				</div><!-- end tab-content-->
			</div><!-- end form-->
			<a href="../dashboard.php"><button class="button button-block" name="logout"/>Dashboard</button></a>
		</ul>
	</div>
<script src='http://cdnjs.cloudflare.com/ajax/libs/jquery/2.1.3/jquery.min.js'></script>
<script src="js/index.js"></script>
</body>
</html>