<?php
session_start();
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);
require '../connect.php';
$msgid=$_REQUEST['id'];
if ( $_SESSION['loggedin'] != 1 ) {
  $_SESSION['message'] = "You must log in before viewing your profile page!";
  header("location: ../error.php");
	exit();
}
elseif ( $_SESSION['banned'] != 0 ) {
	$_SESSION['errormessage'] = "You are banned.";
	header("location: ../error.php");
	exit();
}
$sql = "SELECT * FROM pm WHERE id=:id AND recipient=:recip ORDER BY id desc";
    $stmt = $pdo->prepare($sql);
	$stmt->bindValue(':id', $msgid);
	$stmt->bindValue(':recip', $_SESSION['username']);
    $stmt->execute();
    $user = $stmt->fetch(PDO::FETCH_ASSOC);
	$sender = $user['sender'];
	$subject = $user['subject'];
	$message = $user['message'];

?>
<?php
if(isset($_POST['submit'])){
	$subject2 = !empty($_POST['subject']) ? trim($_POST['subject']) : null;
	$message2 = !empty($_POST['message']) ? trim($_POST['message']) : null;
    $sql = "INSERT INTO pm (sender, recipient, subject, message) VALUES (:sender2, :recipient2, :subject2, :message2)";
    $stmt = $pdo->prepare($sql);
	
	$stmt->bindValue(':sender2', $_SESSION['username']);
	$stmt->bindValue(':recipient2', $sender);
	$stmt->bindValue(':subject2', $subject2);
	$stmt->bindValue(':message2', $message2);
	
	$result = $stmt->execute();
    
    //If the signup process is successful.
    if($result){
        //What you do here is up to you!
		$message = 'Message Sent!';

    echo "<SCRIPT type='text/javascript'> //not showing me this
        alert('$message');
        window.location.replace(\"view-messages.php\");
    </SCRIPT>";
    }
	else {
		$_SESSION['errormessage'] = 'Failed to send message.';
		header("location: ../error.php");
		exit();
	}
}
?>
<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>Reply</title>
<?php include '../css/css.html'; ?>
</head>

<body>
	<div class="form">
		<ul class="tab-group">
			<div class="form">  
				<div class="tab-content"> 
					<form action="reply.php?id=<?= $msgid ?>" method="post">
						 <div class="field-wrap">
            				<font color="white">To</font>
            				<input type="text" id="sender" name="sender" readonly value="<?= $sender ?>">
						 </div>
						<div class="field-wrap">
							<br><font color="white">Subject</font>
            				<input type="text" id="subject" name="subject" readonly value="RE: <?= $subject ?>">
						 </div>
						<div class="field-wrap">
							<br><font color="white">Message</font>
            				<textarea id="message" name="message" cols="25" rows="7" class="messagebox"></textarea>
						 </div>
						 </div>
						<input type="submit" name="submit" value="submit" class="button button button-block">
        			</form>
					<br><a href="view-messages.php"><button class="button button-block" name="logout"/>Back</button></a>
				</div><!-- end tab-content-->
		  		<br><a href="../dashboard.php"><button class="button button-block" name="logout"/>Dashboard</button></a>
			</div><!-- end form-->
		</ul>
	</div>
<script src='http://cdnjs.cloudflare.com/ajax/libs/jquery/2.1.3/jquery.min.js'></script>
<script src="js/index.js"></script>
</body>
</html>