<?php
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

session_start();
$username = $_SESSION['username'];
require '../connect.php';
$msgid=$_REQUEST['id'];
if ( $_SESSION['loggedin'] != 1 ) {
  $_SESSION['message'] = "You must log in before viewing your profile page!";
  header("location: ../error.php");
	exit();
}
elseif ( $_SESSION['banned'] != 0 ) {
	$_SESSION['errormessage'] = "You are banned.";
	header("location: ../error.php");
	exit();
}
$sql = "DELETE FROM pm WHERE id=:id AND recipient=:recip ORDER BY id desc";
    $stmt = $pdo->prepare($sql);
	$stmt->bindValue(':id', $msgid);
	$stmt->bindValue(':recip', $_SESSION['username']);
    $result = $stmt->execute();
	if($result){
        //What you do here is up to you!
		header("location: view-messages.php");
		exit();
    }
else {
	$_SESSION['errormessage'] = 'Could not delete message. Fatal error.';
	header("location: ../error.php");
	exit();
}


?>

<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>Delete PM</title>
<?php include '../css/css.html'; ?>
</head>

<body>
	<div class="form">
		<ul class="tab-group">
			<div class="form">  
				<div class="tab-content"> 
					
				</div><!-- end tab-content-->
		  		<br><a href="../dashboard.php"><button class="button button-block" name="logout"/>Dashboard</button></a>
			</div><!-- end form-->
		</ul>
	</div>
<script src='http://cdnjs.cloudflare.com/ajax/libs/jquery/2.1.3/jquery.min.js'></script>
<script src="js/index.js"></script>
</body>
</html>