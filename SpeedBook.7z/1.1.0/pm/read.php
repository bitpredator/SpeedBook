<?php

session_start();
$username = $_SESSION['username'];
require '../connect.php';
$msgid=$_REQUEST['id'];
if ( $_SESSION['loggedin'] != 1 ) {
  $_SESSION['message'] = "You must log in before viewing your profile page!";
  header("location: ../error.php");
	exit();
}
elseif ( $_SESSION['banned'] != 0 ) {
	$_SESSION['errormessage'] = "You are banned.";
	header("location: ../error.php");
	exit();
}
$sql = "SELECT * FROM pm WHERE id=:id AND recipient=:recip ORDER BY id desc";
    $stmt = $pdo->prepare($sql);
	$stmt->bindValue(':id', $msgid);
	$stmt->bindValue(':recip', $_SESSION['username']);
    $stmt->execute();
    $user = $stmt->fetch(PDO::FETCH_ASSOC);
	$sender = $user['sender'];
	$subject = $user['subject'];
	$message = $user['message'];

?>
<?php
$sql = "UPDATE pm SET isread = :isread WHERE id=:user AND recipient=:recipi";
$stmt = $pdo->prepare($sql);
$stmt->bindValue(':recipi', $_SESSION['username']);
$stmt->bindValue(':user', $msgid);
$stmt->bindValue(':isread', '1');
$result = $stmt->execute();
if($result){
		   }
else{}

?>
<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>Read</title>
<?php include '../css/css.html'; ?>
</head>

<body>
	<div class="form">
		<ul class="tab-group">
			<div class="form">  
				<div class="tab-content"> 
					<form action="read.php?id=<?= $msgid ?>" method="post">
						 <div class="field-wrap">
            				<font color="white">Sender</font>
            				<input type="text" id="sender" name="sender" readonly value="<?= $sender ?>">
						 </div>
						<div class="field-wrap">
							<br><font color="white">Subject</font>
            				<input type="text" id="subject" name="subject" readonly value="<?= $subject ?>">
						 </div>
						<div class="field-wrap">
							<br><font color="white">Message</font>
            				<textarea id="sender" name="sender" readonly cols="25" rows="7" class="messagebox"><?= $message ?></textarea>
						 </div>
						 </div>
        			</form>
					<br><a href="reply.php?id=<?= $msgid ?>"><button class="button button-block" name="logout"/>Reply</button></a>
					<br><a href="view-messages.php"><button class="button button-block" name="logout"/>Back</button></a>
				</div><!-- end tab-content-->
		  		<br><a href="../dashboard.php"><button class="button button-block" name="logout"/>Dashboard</button></a>
			</div><!-- end form-->
		</ul>
	</div>
<script src='http://cdnjs.cloudflare.com/ajax/libs/jquery/2.1.3/jquery.min.js'></script>
<script src="js/index.js"></script>
</body>
</html>