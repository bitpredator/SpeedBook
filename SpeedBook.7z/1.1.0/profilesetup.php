<?php

session_start();
require 'connect.php';

if ( $_SESSION['profilesetup'] == "1" ) {
	$_SESSION['errormessage'] = 'You already set up your profile! Go to account settings to change.';
	header("location: error.php");
	exit();
	
}


//If the POST var "register" exists (our submit button), then we can
//assume that the user has submitted the registration form.
if(isset($_POST['register'])){
    
    //Retrieve the field values from our registration form.
    $discord = !empty($_POST['discord']) ? trim($_POST['discord']) : null;
	$skype = !empty($_POST['skype']) ? trim($_POST['skype']) : null;
	$moto = !empty($_POST['moto']) ? trim($_POST['moto']) : null;
	$other1 = !empty($_POST['other1']) ? trim($_POST['other1']) : null;
	$other2 = !empty($_POST['other2']) ? trim($_POST['other2']) : null;
	$preftruck = !empty($_POST['preftruck']) ? trim($_POST['preftruck']) : null;
    
	
    
    //TO ADD: Error checking (username characters, password length, etc).
    //Basically, you will need to add your own error checking BEFORE
    //the prepared statement is built and executed.
    
    //Now, we need to check if the supplied username already exists.
    
    //Construct the SQL statement and prepare it.
    $sql = "SELECT COUNT(username) AS num FROM users WHERE username = :username";
    $stmt = $pdo->prepare($sql);
    
    //Bind the provided username to our prepared statement.
    $stmt->bindValue(':username', $_SESSION['username']);
    
    //Execute.
    $stmt->execute();
    
    //Fetch the row.
    $row = $stmt->fetch(PDO::FETCH_ASSOC);
    
    //If the provided username already exists - display error.
    //TO ADD - Your own method of handling this error. For example purposes,
    //I'm just going to kill the script completely, as error handling is outside
    //the scope of this tutorial.
    if($row['num'] < 0){
		$_SESSION['errormessage'] = 'Something went wrong. Username not found in database.';
		header("location: error.php");
		exit();
        die();
    }
	
    
    //Prepare our INSERT statement.
    //Remember: We are inserting a new row into our users table.
    $sql = "UPDATE users SET discord = :discord, skype = :skype, moto = :moto, other1 = :other1, other2 = :other2, preftruck = :preftruck, profilesetup = :profilesetup WHERE username = :username";
    $stmt = $pdo->prepare($sql);
    
    //Bind our variables.
	$stmt->bindValue(':discord', $discord);
	$stmt->bindValue(':skype', $skype);
	$stmt->bindValue(':moto', $moto);
	$stmt->bindValue(':other1', $other1);
	$stmt->bindValue(':other2', $other2);
	$stmt->bindValue(':preftruck', $preftruck);
	$stmt->bindValue(':profilesetup', '1');
	$stmt->bindValue(':username', $_SESSION['username']);

 
    //Execute the statement and insert the new account.
    $result = $stmt->execute();
    
    //If the signup process is successful.
    if($result){
        //What you do here is up to you!
		$_SESSION['successmessage'] = 'Profile Complete!';
		header("location: success.php");
		exit();
    }
    
}
 
?>
<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>Registration</title>
<script type="text/JavaScript" src="js/sha512.js"></script> 
<script type="text/JavaScript" src="js/forms.js"></script>
<link href="https://fonts.googleapis.com/css?family=Titillium+Web" rel="stylesheet">
<?php include 'css/css.html'; ?>
</head>

<body>
	<div class="form">
		<ul class="tab-group">
			<div class="form">  
				<div class="tab-content"> 
					
        			<center></center><br><form action="profilesetup.php" method="post">
					<h1>Continue Profile Setup</h1><br><br>
						<br /><div class="field-wrap">
            				<label for="username">Discord</label>
            				<input type="text" id="discord" name="discord" maxlength="30" autocomplete="new-password"><br>
						</div>
			
						<div class="field-wrap">
           				<label for="password">Skype</label>
            				<input type="text" id="skype" name="skype" maxlength="25" autocomplete="new-password"><br>
						</div>
			
						<div class="field-wrap">
							<label for="email">Moto</label>
            				<input type="text" id="moto" name="moto" maxlength="120" autocomplete="new-password"><br>
						</div>
			
						<div class="field-wrap">
							<label for="firstname">Other Contact Method Name</label>
            				<input type="text" id="other1" name="other1" maxlength="30" autocomplete="new-password"><br>
						</div>
			
						<div class="field-wrap">
							<label for="lastname">Other Contact Method Link</label>
            				<input type="text" id="other2" name="other2" maxlength="120" autocomplete="new-password"><br>
						</div>
			
						<div class="field-wrap"><select name="preftruck" class="field select medium" required class="dropbox">
							<label for="preftruck">Preferred Truck</label><span class="req">*</span>
							<option value="">Preferred Truck</option>
				  			<option value="Peterbilt">Peterbilt</option>
				  			<option value="Kenworth">Kenworth</option>
							<option value="DAF">DAF</option>
							<option value="Iveco">Iveco</option>
							<option value="MAN">MAN</option>
							<option value="Kenworth">Kenworth</option>
							<option value="Mercedes-Benz">Mercedes-Benz</option>
							<option value="Renault">Renault</option>
							<option value="Scania">Scania</option>
							<option value="Volvo">Volvo</option>
					</select><br><br>
							<b><font color="white">All information listed on this page will be public!</font></b>
						</div>

            <input type="submit" name="register" value="Finish" class="button button button-block"></button>
					</form></center>
				</div><!-- end tab-content-->
			</div><!-- end form-->
		</ul>
	</div>
<script src='http://cdnjs.cloudflare.com/ajax/libs/jquery/2.1.3/jquery.min.js'></script>
<script src="js/index.js"></script>
</body>
</html>