<?php
//ini_set('display_errors', 1);
//ini_set('display_startup_errors', 1);
//error_reporting(E_ALL);

session_start();
require 'lib/password.php';
require 'connect.php';

$sql = "SELECT regopen from vtcinformation";
$stmt = $pdo->prepare($sql);
$stmt->execute();
$row = $stmt->fetch(PDO::FETCH_ASSOC);
if($row['regopen'] == 'no'){
	$_SESSION['errormessage'] = 'Sorry. Account registration is currently closed. Try again later.';
	header("location: error.php");
	exit();	
}
else {
	
}
?>
<?php

//If the POST var "register" exists (our submit button), then we can
//assume that the user has submitted the registration form.
if(isset($_POST['register'])){
    
    //Retrieve the field values from our registration form.
    $username = !empty($_POST['username']) ? trim($_POST['username']) : null;
    $pass = !empty($_POST['password']) ? trim($_POST['password']) : null;
	$email = !empty($_POST['email']) ? trim($_POST['email']) : null;
	$firstname = !empty($_POST['firstname']) ? trim($_POST['firstname']) : null;
	$lastname = !empty($_POST['lastname']) ? trim($_POST['lastname']) : null;
	$truckersmpurl = !empty($_POST['truckersmpurl']) ? trim($_POST['truckersmpurl']) : null;
	$steam64id = !empty($_POST['steam64id']) ? trim($_POST['steam64id']) : null;
	$steamurl = !empty($_POST['steamurl']) ? trim($_POST['steamurl']) : null;
	
    
    //TO ADD: Error checking (username characters, password length, etc).
    //Basically, you will need to add your own error checking BEFORE
    //the prepared statement is built and executed.
    
    //Now, we need to check if the supplied username already exists.
    
    //Construct the SQL statement and prepare it.
    $sql = "SELECT COUNT(username) AS num FROM users WHERE username = :username";
    $stmt = $pdo->prepare($sql);
    
    //Bind the provided username to our prepared statement.
    $stmt->bindValue(':username', $username);
    
    //Execute.
    $stmt->execute();
    
    //Fetch the row.
    $row = $stmt->fetch(PDO::FETCH_ASSOC);
    
    //If the provided username already exists - display error.
    //TO ADD - Your own method of handling this error. For example purposes,
    //I'm just going to kill the script completely, as error handling is outside
    //the scope of this tutorial.
    if($row['num'] > 0){
		$_SESSION['errormessage'] = 'Username already registered!';
		header("location: error.php");
		exit();
        die();
    }
	
	$sql = "SELECT COUNT(email) AS num FROM users WHERE email = :email";
    $stmt = $pdo->prepare($sql);
    
    //Bind the provided username to our prepared statement.
    $stmt->bindValue(':email', $email);
    
    //Execute.
    $stmt->execute();
    
    //Fetch the row.
    $row = $stmt->fetch(PDO::FETCH_ASSOC);
    
    //If the provided username already exists - display error.
    //TO ADD - Your own method of handling this error. For example purposes,
    //I'm just going to kill the script completely, as error handling is outside
    //the scope of this tutorial.
    if($row['num'] > 0){
		$_SESSION['errormessage'] = 'Email already registered!';
		header("location: error.php");
		exit();
        die();
    }
    
    //Hash the password as we do NOT want to store our passwords in plain text.
    $passwordHash = password_hash($pass, PASSWORD_BCRYPT, array("cost" => 12));
    
    //Prepare our INSERT statement.
    //Remember: We are inserting a new row into our users table.
    $sql = "INSERT INTO users (firstname, lastname, email, password, truckersmpurl, steam64id, steamurl, username, active, regdate) VALUES (:firstname, :lastname, :email, :password, :truckersmpurl, :steam64id, :steamurl, :username, :active, :regdate)";
    $stmt = $pdo->prepare($sql);
    
    //Bind our variables.
	$stmt->bindValue(':firstname', $firstname);
	$stmt->bindValue(':lastname', $lastname);
	$stmt->bindValue(':email', $email);
	$stmt->bindValue(':password', $passwordHash);
	$stmt->bindValue(':truckersmpurl', $truckersmpurl);
	$stmt->bindValue(':steam64id', $steam64id);
	$stmt->bindValue(':steamurl', $steamurl);
    $stmt->bindValue(':username', $username);
	$stmt->bindValue(':active', '1');
	$stmt->bindValue(':regdate', date("Y-m-d"));

 
    //Execute the statement and insert the new account.
    $result = $stmt->execute();
    
    //If the signup process is successful.
    if($result){
        //What you do here is up to you!
		$_SESSION['successmessage'] = 'Thanks for registering! You can now login.';
		header("location: success.php");
		exit();
    }
    
}
 
?>
<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>Registration</title>
<script type="text/JavaScript" src="js/sha512.js"></script> 
<script type="text/JavaScript" src="js/forms.js"></script>
<link href="https://fonts.googleapis.com/css?family=Titillium+Web" rel="stylesheet">
<?php include 'css/css.html'; ?>
</head>

<body>
	<div class="form">
		<ul class="tab-group">
			<div class="form">  
				<div class="tab-content"> 
					
        			<center></center><br><form action="register.php" method="post">
					<h1>Register</h1><br><br>
						<br /><div class="field-wrap">
            				<label for="username">Username</label>
            				<input type="text" id="username" name="username" maxlength="20" required autocomplete="new-password"><br>
						</div>
			
						<div class="field-wrap">
           				<label for="password">Password</label>
            				<input type="password" id="password" name="password" maxlength="25" required autocomplete="new-password"><br>
						</div>
			
						<div class="field-wrap">
							<label for="email">Email</label>
            				<input type="email" id="email" name="email" maxlength="45" required autocomplete="new-password"><br>
						</div>
			
						<div class="field-wrap">
							<label for="firstname">First Name</label>
            				<input type="text" id="firstname" name="firstname" maxlength="25" required autocomplete="new-password"><br>
						</div>
			
						<div class="field-wrap">
							<label for="lastname">Last Name</label>
            				<input type="text" id="lastname" name="lastname" maxlength="25" autocomplete="new-password"><br>
						</div>
			
						<div class="field-wrap">
							<label for="truckersmpurl">Truckers MP Profile URL</label>
            				<input type="text" id="truckersmpurl" name="truckersmpurl" maxlength="200" required autocomplete="new-password"><br>
						</div>
			
						<div class="field-wrap">
							<label for="firstname">Steam64id</label>
            				<input type="text" id="steam64id" name="steam64id" maxlength="45" required autocomplete="new-password"><br>
						</div>
			
						<div class="field-wrap">
							<label for="firstname">Steam Profile URL</label>
            				<input type="text" id="steamurl" name="steamurl" required autocomplete="new-password"><br>
						</div>

            <input type="submit" name="register" value="Register" class="button button button-block"></button>
					</form></center>
				</div><!-- end tab-content-->
			</div><!-- end form-->
		</ul>
	</div>
<script src='http://cdnjs.cloudflare.com/ajax/libs/jquery/2.1.3/jquery.min.js'></script>
<script src="js/index.js"></script>
</body>
</html>