<?php
session_start();
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);
require '../connect.php';
if ( $_SESSION['loggedin'] != 1 ) {
  $_SESSION['message'] = "You must log in before viewing your profile page!";
  header("location: ../error.php");
	exit();
}
elseif ( $_SESSION['banned'] != 0 ) {
	$_SESSION['errormessage'] = "You are banned.";
	header("location: ../error.php");
	exit();
}
$sql = "SELECT * FROM users WHERE username=:username ORDER BY id desc";
    $stmt = $pdo->prepare($sql);
	$stmt->bindValue(':username', $_SESSION['username']);
    $stmt->execute();
    $user = $stmt->fetch(PDO::FETCH_ASSOC);
	$firstname = $user['firstname'];
	$lastname = $user['lastname'];
	$email = $user['email'];
	$preftruck = $user['preftruck'];
	$truckersmpurl = $user['truckersmpurl'];
	$steam64id = $user['steam64id'];
	$steamurl = $user['steamurl'];
	$discord = $user['discord'];
	$other1 = $user['other1'];
	$other2 = $user['other2'];
	$skype = $user['skype'];
	$motto = $user['moto'];

?>
<?php
if(isset($_POST['submit'])){
	$fn = !empty($_POST['firstname']) ? trim($_POST['firstname']) : null;
	$ln = !empty($_POST['lastname']) ? trim($_POST['lastname']) : null;
	$em = !empty($_POST['email']) ? trim($_POST['email']) : null;
	$tmpurl = !empty($_POST['truckersmpurl']) ? trim($_POST['truckersmpurl']) : null;
	$s64id = !empty($_POST['steam64id']) ? trim($_POST['steam64id']) : null;
	$surl = !empty($_POST['steamurl']) ? trim($_POST['steamurl']) : null;
	$o1 = !empty($_POST['other1']) ? trim($_POST['other1']) : null;
	$o2 = !empty($_POST['other2']) ? trim($_POST['other2']) : null;
	$sky = !empty($_POST['skype']) ? trim($_POST['skype']) : null;
	$mt = !empty($_POST['moto']) ? trim($_POST['moto']) : null;
	$passwordAttempt = !empty($_POST['password']) ? trim($_POST['password']) : null;
	

	
	
	$stmt->execute();
	
	$user = $stmt->fetch(PDO::FETCH_ASSOC);
	
	if($user === false){
        $_SESSION['errormessage'] = 'Incorrect password combination.';
		header("location: ../error.php");
		exit();
        die();
    } else{
        $validPassword = password_verify($passwordAttempt, $user['password']);
    
    if($validPassword){
        //What you do here is up to you!
		$message = 'Profile updated successfully!';

    echo "<SCRIPT type='text/javascript'> //not showing me this
        alert('$message');
        window.location.replace(\"settings.php\");
    </SCRIPT>";
		
		    $sql = "UPDATE users SET firstname = :firstname, lastname = :lastname, email = :email, truckersmpurl = :truckersmpurl, steam64id = :steam64id, steamurl = :steamurl, other1 = :other1, other2 = :other2, skype = :skype, moto = :moto WHERE username = :username";
    $stmt = $pdo->prepare($sql);
	
	$stmt->bindValue(':username', $_SESSION['username']);
	$stmt->bindValue(':firstname', $fn);
	$stmt->bindValue(':lastname', $ln);
	$stmt->bindValue(':email', $em);
	$stmt->bindValue(':truckersmpurl', $tmpurl);
	$stmt->bindValue(':steam64id', $s64id);
	$stmt->bindValue(':steamurl', $surl);
	$stmt->bindValue(':other1', $o1);
	$stmt->bindValue(':other2', $o2);
	$stmt->bindValue(':skype', $sky);
	$stmt->bindValue(':moto', $mt);
		
    }
	else {
		$_SESSION['errormessage'] = 'Password Incorrect.';
		header("location: ../error.php");
		exit();
	}
	}
}

?>
<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>Reply</title>
<?php include '../css/css.html'; ?>
</head>

<body>
	<div class="form">
		<ul class="tab-group">
			<div class="form">  
				<div class="tab-content"> 
					<form action="settings.php" method="post">
						 <div class="field-wrap">
            				<font color="white">First Name</font>
            				<input type="text" name="firstname" value="<?= $firstname ?>">
						 </div>
						
						<div class="field-wrap">
            				<font color="white">Last Name</font>
            				<input type="text" name="lastname" value="<?= $lastname ?>">
						 </div>
						
						<div class="field-wrap">
            				<font color="white">Email</font>
            				<input type="email" name="email" value="<?= $email ?>">
						 </div>
						
						
						<div class="field-wrap">
            				<font color="white">TruckersMP Profile URL</font>
            				<input type="text" name="truckersmpurl" value="<?= $truckersmpurl ?>">
						 </div>
						
						<div class="field-wrap">
            				<font color="white">Steam64id</font>
            				<input type="text" name="Steam64id" value="<?= $steam64id ?>">
						 </div>
						
						<div class="field-wrap">
            				<font color="white">Discord</font>
            				<input type="text" name="discord" value="<?= $discord ?>">
						 </div>
						
						<div class="field-wrap">
            				<font color="white">Other Contact Method Name</font>
            				<input type="text" name="other1" value="<?= $other1 ?>">
						 </div>
						
						<div class="field-wrap">
            				<font color="white">Other Contact Method URL/Handle</font>
            				<input type="text" name="other2" value="<?= $other2 ?>">
						 </div>
						
						<div class="field-wrap">
            				<font color="white">Skype</font>
            				<input type="text" name="skype" value="<?= $skype ?>">
						 </div>
						
						<div class="field-wrap">
            				<font color="white">Motto</font>
            				<input type="text" name="motto" value="<?= $motto ?>">
						 </div>
						
						<div class="field-wrap">
            				<font color="white">Enter Password to Confirm Changes:</font>
            				<input type="password" name="password" value="">
						 </div>
						
						 </div>
						<input type="submit" name="submit" value="submit" class="button button button-block">
        			</form>
				</div><!-- end tab-content-->
		  		<br><a href="../dashboard.php"><button class="button button-block" name="logout"/>Dashboard</button></a>
			</div><!-- end form-->
		</ul>
	</div>
<script src='http://cdnjs.cloudflare.com/ajax/libs/jquery/2.1.3/jquery.min.js'></script>
<script src="js/index.js"></script>
</body>
</html>