<?php
session_start();
require '../../connect.php';
$username = $_SESSION['username'];
if ( $_SESSION['loggedin'] != 1 ) {
  $_SESSION['message'] = "You must log in before viewing your profile page!";
  header("location: ../../error.php");
	exit();
}
elseif ( $_SESSION['banned'] != 0 ) {
	$_SESSION['errormessage'] = "You are banned.";
	header("location: ../../error.php");
	exit();
}
?>
<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>List Jobs</title>
<script src="http://ajax.googleapis.com/ajax/libs/jquery/1.11.1/jquery.min.js">        </script>
<script src="js/typeahead.min.js"></script>
<?php include 'css/css.html'; ?>
</head>

<body>
	<div class="form">
		<ul class="tab-group">
			<div class="form">  
				<div class="tab-content"> 
					<h1>List of your logged jobs:</h1><br>
					<table>
        				<thead>
							<tr>
        					<th>Departing City</th>
        					<th>Arrival City</th>
        					<th>Date</th>
							<th></th>
							</tr>
    					<thead>
						<tbody>
					<?php
					$sql = "SELECT * FROM jobslog WHERE emp=:employee ORDER BY id desc";
					$stmt = $pdo->prepare($sql);
					$stmt->bindValue(':employee', $username);
					$stmt->execute();
					while ($user = $stmt->fetch(PDO::FETCH_ASSOC)) { 
					$id = $user['id'];
					?>
						<tr>
							<td><?= $user['depcity'] ?></td>
							<td><?= $user['arrcity'] ?></td>
							<td><?= $user['date'] ?></td>
							<td><a href='viewjob.php?id=<?= $id ?>'>View</a></td>
						</tr>
					<?php
					} ?>
				</div><!-- end tab-content-->
					<br><a href="../stats.php"><button class="button button-block" name="logout"/>Back</button></a><br>
			</div><!-- end form-->	
				<a href="../../dashboard.php"><button class="button button-block" name="logout"/>Dashboard</button></a><br>
		</ul>	
	</div>
<script src='http://cdnjs.cloudflare.com/ajax/libs/jquery/2.1.3/jquery.min.js'></script>
<script src="js/index.js"></script>
	<script>
    $(document).ready(function(){
    $('input.typeahead').typeahead({
        name: 'typeahead',
        remote:'search.php?key=%QUERY',
        limit : 10
    });
});
    </script>
</body>
</html>