<?php
session_start();
require '../../connect.php';
$jobid=$_REQUEST['id'];
$username = $_SESSION['username'];
if ( $_SESSION['loggedin'] != 1 ) {
  $_SESSION['message'] = "You must log in before viewing your profile page!";
  header("location: ../../error.php");
	exit();
}
elseif ( $_SESSION['banned'] != 0 ) {
	$_SESSION['errormessage'] = "You are banned.";
	header("location: ../../error.php");
	exit();
}
?>
<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>Job</title>
<script src="http://ajax.googleapis.com/ajax/libs/jquery/1.11.1/jquery.min.js">        </script>
<script src="js/typeahead.min.js"></script>
<?php include 'css/css.html'; ?>
</head>

<body>
	<div class="form">
		<ul class="tab-group">
			<div class="form">  
				<div class="tab-content"> 
					<?php
					$sql = "SELECT * FROM jobslog WHERE emp=:employee AND id=:jobid ORDER BY id desc";
					$stmt = $pdo->prepare($sql);
					$stmt->bindValue(':employee', $username);
					$stmt->bindValue(':jobid', $jobid);
					$stmt->execute();
					$user = $stmt->fetch(PDO::FETCH_ASSOC);
					$id = $user['id'];
					?>
						<font color="white"><b><u>Job Information - Job ID(<?= $user['id'] ?>)</u></b></font><br><br>
						<font color="#1ab188"><b>Departure City - </b></font><font color="white"><?= $user['depcity'] ?></font><br>
						<font color="#1ab188"><b>Arrival City - </b></font><font color="white"><?= $user['arrcity'] ?></font><br>
						<font color="#1ab188"><b>Cargo - </b></font><font color="white"><?= $user['cargo'] ?></font><br>
						<font color="#1ab188"><b>Distance - </b></font><font color="white"><?= $user['distance'] ?>Km</font><br>
						<font color="#1ab188"><b>Fuel Consumed - </b></font><font color="white"><?= $user['fuelcon'] ?>L</font><br>
						<font color="#1ab188"><b>Weight - </b></font><font color="white"><?= $user['weight'] ?> Tons</font><br>
						<font color="#1ab188"><b>Profits - </b></font><font color="white">$<?= $user['profits'] ?></font><br>
						<font color="#1ab188"><b>Toll Costs - </b></font><font color="white">$<?= $user['toll'] ?></font><br>
						<font color="#1ab188"><b>Your Pay - </b></font><font color="white">$<?= $user['pay'] ?></font><br>
						<font color="#1ab188"><b>Date - </b></font><font color="white"><?= $user['date'] ?></font><br>
						<font color="#1ab188"><b>Comments - </b></font><font color="white"><?= $user['comment'] ?></font><br><br><br>

				</div><!-- end tab-content-->
					<br><a href="jobs.php"><button class="button button-block" name="logout"/>Back</button></a><br>
			</div><!-- end form-->	
				<a href="../../dashboard.php"><button class="button button-block" name="logout"/>Dashboard</button></a>
		</ul>	
	</div>
<script src='http://cdnjs.cloudflare.com/ajax/libs/jquery/2.1.3/jquery.min.js'></script>
<script src="js/index.js"></script>
	<script>
    $(document).ready(function(){
    $('input.typeahead').typeahead({
        name: 'typeahead',
        remote:'search.php?key=%QUERY',
        limit : 10
    });
});
    </script>
</body>
</html>