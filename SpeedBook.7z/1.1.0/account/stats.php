<?php
session_start();
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);
require '../connect.php';
if ( $_SESSION['loggedin'] != 1 ) {
  $_SESSION['message'] = "You must log in before viewing your profile page!";
  header("location: ../error.php");
	exit();
}
elseif ( $_SESSION['banned'] != 0 ) {
	$_SESSION['errormessage'] = "You are banned.";
	header("location: ../error.php");
	exit();
}
?>
<?php
$sql = "SELECT id, truckersmpurl, steam64id, steamurl, discord, other1, other2, bank, totaldeliveries, totalkms, totaloffences, userlevel, username, skype, moto, regdate, preftruck FROM users WHERE username=:username";
    $stmt = $pdo->prepare($sql);
	$stmt->bindValue(':username', $_SESSION['username']);
    $stmt->execute();
    $user = $stmt->fetch(PDO::FETCH_ASSOC);
	$truckersmpurl = $user['truckersmpurl'];
	$steam64id = $user['steam64id'];
	$steamurl = $user['steamurl'];
	$discord = $user['discord'];
	$other1 = $user['other1'];
	$other2 = $user['other2'];
	$bank = $user['bank'];
	$totaldeliveries = $user['totaldeliveries'];
	$totalkms = $user['totalkms'];
	$totaloffences = $user['totaloffences'];
	$userlevel = $user['userlevel'];
	$username = $user['username'];
	$skype = $user['skype'];
	$moto = $user['moto'];
	$regdate = $user['regdate'];
	$preftruck = $user['preftruck'];
	$id = $user['id'];
?>
<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>User Stats</title>
<?php include 'css/css.html'; ?>
</head>

<body>
	<div class="form">
		<ul class="tab-group">
			<div class="form">  
				<div class="tab-content"> 
					<h2><?= $username ?></h2><br>
					<center><font color="white"><?= $userlevel ?></font><br>
						<font color="white"><i><?= $moto ?></i></font><br><br></center>
					
					<font color="white"><b><u>Public Contact Information:</u></b></font><br>
					<font color="#D3D3D3"><b>Discord - </b></font><font color="white"><?= $discord ?></font><br>
					<font color="#D3D3D3"><b>Skype - </b></font><font color="white"><?= $skype ?></font><br>
					<font color="#D3D3D3"><b>TruckersMP Profile - </b></font><font color="white"><a href="<?= $truckersmpurl ?>">Click Here</a></font><br>
					<font color="#D3D3D3"><b>Steam64id - </b></font><font color="white"><?= $steam64id ?></font><br>
					<font color="#D3D3D3"><b>Steam Profile URL - </b></font><font color="white"><a href="<?= $steamurl ?>">Click Here</a></font><br>
					<font color="#D3D3D3"><b><?= $other1 ?> - </b></font><font color="white"><?= $other2 ?></font><br><br><br>
					
					<font color="white"><b><u>User Stats:</u></b></font><br>
					<font color="#D3D3D3"><b>Registered On - </b></font><font color="white"><?= $regdate ?></font><br>
					<font color="#D3D3D3"><b>Preferred Truck - </b></font><font color="white"><?= $preftruck ?></font><br>
					<font color="#D3D3D3"><b>Total KMs - </b></font><font color="white"><?= $totalkms ?></font><br>
					<font color="#D3D3D3"><b>Total Jobs Logged - </b></font><font color="white"><?= $totaldeliveries ?></font><br>
					<font color="#D3D3D3"><b>Total Offences - </b></font><font color="white"><?= $totaloffences ?></font><br>
					<font color="#D3D3D3"><b>Net Worth - </b></font><font color="white">$<?= $bank ?></font><br><br><br>
					
					<a href="view/jobs.php"><button title="Report" target="_self" class="dashlinks dashlinks-block">View Logged Jobs</button></a>
					<a href="view/incident.php"><button title="Report" target="_self" class="dashlinks dashlinks-block">View Incident Reports</button></a>
					<a href="view/maintenance.php"><button title="Report" target="_self" class="dashlinks dashlinks-block">View Maintenance Reports</button></a>
					</ul>
				</div><!-- end tab-content-->		
			</div><!-- end form-->	
				<a href="../dashboard.php"><button class="button button-block" name="logout"/>Dashboard</button></a>	
	</div>
<script src='http://cdnjs.cloudflare.com/ajax/libs/jquery/2.1.3/jquery.min.js'></script>
<script src="js/index.js"></script>
</body>
</html>